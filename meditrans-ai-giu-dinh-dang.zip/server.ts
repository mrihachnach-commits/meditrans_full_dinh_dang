import express from "express";
import path from "path";
import { firebaseConfig } from "./lib/firebaseAdmin.js";

// Import handlers for local mapping
import pingHandler from "./api/ping";
import diagnosticsHandler from "./api/admin/diagnostics";
import createUserHandler from "./api/admin/create-user";
import listUsersHandler from "./api/admin/list-users";
import deleteUserHandler from "./api/admin/delete-user";
import changePasswordHandler from "./api/admin/change-password";
import driveDownloadHandler from "./api/drive/download";
import aiChatHandler from "./api/ai/chat";
import indexHandler from "./api/index";

const PORT = 3000;

async function start() {
  const app = express();
  // Ảnh trang (base64) có thể nặng vài MB — giới hạn mặc định 100KB của express.json() quá nhỏ.
  // Vercel tự giới hạn ~4.5MB cho serverless function nên giá trị này chủ yếu dành cho AI Studio / chạy local.
  app.use(express.json({ limit: "12mb" }));

  // Manually map routes for local development
  app.get("/api/ping", pingHandler);
  app.get("/api/admin/diagnostics", diagnosticsHandler);
  app.post("/api/admin/create-user", createUserHandler);
  app.get("/api/admin/list-users", listUsersHandler);
  app.post("/api/admin/delete-user", deleteUserHandler);
  app.post("/api/admin/change-password", changePasswordHandler);
  app.get("/api/drive/download", driveDownloadHandler);
  app.post("/api/ai/chat", aiChatHandler);
  app.get("/api", indexHandler);
  app.get("/api/index", indexHandler);

  // SPA Middleware for local development
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Local Dev] Server running on http://localhost:${PORT}`);
    if (firebaseConfig.error) {
      console.warn("[Warning] Firebase Config Error:", firebaseConfig.error);
    }
  });
}

start();
