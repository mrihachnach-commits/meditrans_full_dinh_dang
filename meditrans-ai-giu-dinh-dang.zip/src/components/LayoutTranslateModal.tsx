import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { PDFDocumentProxy } from 'pdfjs-dist';
import { saveAs } from 'file-saver';
import {
  X, LayoutTemplate, Play, Square, Download, RefreshCw, ZoomIn, ZoomOut,
  Columns2, Image as ImageIcon, FileText, AlertTriangle, CheckCircle2, Loader2, ScanLine, ChevronLeft, ChevronRight,
} from 'lucide-react';
import {
  LayoutBlockTranslator,
  LayoutPageResult,
  deleteLayoutPages,
  exportLayoutPdf,
  loadLayoutPages,
  parsePageRange,
  saveLayoutPage,
  translatePageWithLayout,
} from '../services/layoutTranslationService';

interface LayoutTranslateModalProps {
  onClose: () => void;
  pdfDoc: PDFDocumentProxy;
  numPages: number;
  currentPage: number;
  docKey: string;
  fileName: string;
  translator: LayoutBlockTranslator | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

type ViewMode = 'translated' | 'side' | 'original';

function friendlyError(err: any): string {
  const msg = String(err?.message || err || '');
  if (/level 2/i.test(msg)) return 'Tài khoản chưa đủ Level 2 để dùng Key hệ thống.';
  if (/api key|key khả dụng/i.test(msg)) return 'Không có API Key khả dụng. Kiểm tra lại Key trong Cài đặt.';
  if (/429|quota|resource_exhausted/i.test(msg)) return 'Key đang hết hạn mức (429). Thử lại sau ít phút.';
  if (/json|hợp lệ/i.test(msg)) return 'AI trả về dữ liệu không đúng định dạng. Hãy dịch lại trang này.';
  return msg.slice(0, 160) || 'Lỗi không xác định';
}

export const LayoutTranslateModal: React.FC<LayoutTranslateModalProps> = ({
  onClose, pdfDoc, numPages, currentPage, docKey, fileName, translator, showToast,
}) => {
  const [results, setResults] = useState<Record<number, LayoutPageResult>>({});
  const [errors, setErrors] = useState<Record<number, string>>({});
  const [rangeInput, setRangeInput] = useState(String(currentPage));
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number; page: number | null }>({ done: 0, total: 0, page: null });
  const [selected, setSelected] = useState<number>(currentPage);
  const [viewMode, setViewMode] = useState<ViewMode>('translated');
  const [zoom, setZoom] = useState(1);
  const [exporting, setExporting] = useState(false);
  const [loadingCache, setLoadingCache] = useState(true);
  const [originalUrls, setOriginalUrls] = useState<Record<number, string>>({});

  const abortRef = useRef<AbortController | null>(null);
  const urlCache = useRef<Map<number, { blob: Blob; url: string }>>(new Map());
  const originalUrlsRef = useRef<Record<number, string>>({});

  /* -------- ảnh bản dịch (object URL) -------- */
  const urlFor = useCallback((r?: LayoutPageResult) => {
    if (!r) return null;
    const hit = urlCache.current.get(r.pageNumber);
    if (hit && hit.blob === r.blob) return hit.url;
    if (hit) URL.revokeObjectURL(hit.url);
    const url = URL.createObjectURL(r.blob);
    urlCache.current.set(r.pageNumber, { blob: r.blob, url });
    return url;
  }, []);

  useEffect(() => {
    const cacheRef = urlCache.current;
    return () => {
      abortRef.current?.abort();
      cacheRef.forEach(v => URL.revokeObjectURL(v.url));
      Object.values(originalUrlsRef.current).forEach(u => URL.revokeObjectURL(u));
    };
  }, []);

  /* -------- đọc đệm khi mở -------- */
  useEffect(() => {
    let alive = true;
    setLoadingCache(true);
    loadLayoutPages(docKey, numPages).then(cached => {
      if (!alive) return;
      setResults(cached);
      setLoadingCache(false);
    });
    return () => { alive = false; };
  }, [docKey, numPages]);

  /* -------- ảnh trang gốc cho chế độ so sánh -------- */
  useEffect(() => {
    if (viewMode === 'translated' || originalUrlsRef.current[selected]) return;
    let alive = true;
    (async () => {
      try {
        const page: any = await pdfDoc.getPage(selected);
        const base = page.getViewport({ scale: 1 });
        const viewport = page.getViewport({ scale: Math.min(2.5, Math.max(1.2, 1400 / base.width)) });
        const canvas = document.createElement('canvas');
        canvas.width = Math.floor(viewport.width);
        canvas.height = Math.floor(viewport.height);
        const ctx = canvas.getContext('2d')!;
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        await page.render({ canvasContext: ctx, viewport }).promise;
        const blob: Blob | null = await new Promise(r => canvas.toBlob(r, 'image/jpeg', 0.85));
        if (!blob || !alive) return;
        const url = URL.createObjectURL(blob);
        originalUrlsRef.current[selected] = url;
        setOriginalUrls(prev => ({ ...prev, [selected]: url }));
      } catch (e) {
        console.warn('[Layout] Không render được trang gốc:', e);
      }
    })();
    return () => { alive = false; };
  }, [viewMode, selected, pdfDoc]);

  /* -------- dịch -------- */
  const runPages = useCallback(async (pages: number[], force = false) => {
    if (!translator) {
      showToast('Chưa có API Key để dịch. Vui lòng thêm Key trong Cài đặt.', 'error');
      return;
    }
    const todo = force ? pages : pages.filter(p => !results[p]);
    if (todo.length === 0) {
      showToast('Các trang đã chọn đều đã được dịch. Bấm "Dịch lại" nếu muốn dịch mới.', 'info');
      return;
    }
    const controller = new AbortController();
    abortRef.current = controller;
    setRunning(true);
    setProgress({ done: 0, total: todo.length, page: todo[0] });
    if (!results[selected]) setSelected(todo[0]);

    let ok = 0;
    for (let i = 0; i < todo.length; i++) {
      const p = todo[i];
      if (controller.signal.aborted) break;
      setProgress({ done: i, total: todo.length, page: p });
      setErrors(prev => { const n = { ...prev }; delete n[p]; return n; });
      try {
        const res = await translatePageWithLayout(pdfDoc, p, translator, controller.signal);
        await saveLayoutPage(docKey, res);
        setResults(prev => ({ ...prev, [p]: res }));
        if (i === 0) setSelected(p);
        ok++;
      } catch (err: any) {
        if (controller.signal.aborted || /aborted/i.test(String(err?.message))) break;
        console.error(`[Layout] Lỗi dịch trang ${p}:`, err);
        setErrors(prev => ({ ...prev, [p]: friendlyError(err) }));
        if (/level 2|api key|key khả dụng/i.test(String(err?.message))) break;
      }
    }
    setProgress(prev => ({ ...prev, done: prev.total, page: null }));
    setRunning(false);
    abortRef.current = null;
    if (controller.signal.aborted) showToast(`Đã dừng. Hoàn thành ${ok} trang.`, 'info');
    else if (ok > 0) showToast(`Đã dịch giữ định dạng ${ok} trang.`, 'success');
  }, [translator, results, selected, pdfDoc, docKey, showToast]);

  const handleStart = () => {
    const pages = parsePageRange(rangeInput, numPages);
    if (pages.length === 0) {
      showToast(`Khoảng trang không hợp lệ. Ví dụ: 1-3, 5 (tối đa ${numPages}).`, 'error');
      return;
    }
    runPages(pages);
  };

  const handleRetranslate = async () => {
    await deleteLayoutPages(docKey, [selected]);
    setResults(prev => { const n = { ...prev }; delete n[selected]; return n; });
    runPages([selected], true);
  };

  /* -------- xuất -------- */
  const baseName = useMemo(() => (fileName || 'tai-lieu').replace(/\.pdf$/i, ''), [fileName]);

  const handleExport = async (scope: 'range' | 'all') => {
    const wanted = scope === 'all'
      ? Object.keys(results).map(Number)
      : parsePageRange(rangeInput, numPages).filter(p => results[p]);
    const pages = wanted.map(p => results[p]).filter(r => r && !r.scanned);
    if (pages.length === 0) {
      showToast('Chưa có trang nào được dịch để xuất.', 'error');
      return;
    }
    setExporting(true);
    try {
      const blob = await exportLayoutPdf(pages);
      saveAs(blob, `${baseName}_ban-dich-giu-dinh-dang.pdf`);
      showToast(`Đã xuất PDF ${pages.length} trang.`, 'success');
    } catch (e: any) {
      showToast(`Lỗi xuất PDF: ${e?.message || e}`, 'error');
    } finally {
      setExporting(false);
    }
  };

  const handleDownloadImage = () => {
    const r = results[selected];
    if (!r) return;
    saveAs(r.blob, `${baseName}_trang-${selected}_ban-dich.jpg`);
  };

  /* -------- hiển thị -------- */
  const translatedCount = Object.keys(results).length;
  const current = results[selected];
  const currentUrl = urlFor(current);
  const originalUrl = originalUrls[selected];
  const pct = progress.total ? Math.round((progress.done / progress.total) * 100) : 0;

  const statusIcon = (p: number) => {
    if (running && progress.page === p) return <Loader2 className="w-3 h-3 animate-spin text-indigo-500" />;
    if (errors[p]) return <AlertTriangle className="w-3 h-3 text-rose-500" />;
    const r = results[p];
    if (!r) return null;
    if (r.scanned) return <ScanLine className="w-3 h-3 text-amber-500" />;
    if (r.overflowCount > 0) return <AlertTriangle className="w-3 h-3 text-amber-500" />;
    return <CheckCircle2 className="w-3 h-3 text-emerald-500" />;
  };

  const imgStyle: React.CSSProperties = { width: `${zoom * 100}%`, maxWidth: 'none' };

  return (
    <div className="fixed inset-0 z-[160] flex items-stretch justify-center bg-slate-900/70 backdrop-blur-sm p-0 md:p-4">
      <div className="bg-white w-full max-w-[1400px] md:rounded-3xl shadow-2xl overflow-hidden flex flex-col border border-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 px-4 md:px-6 py-3 border-b border-slate-100 bg-gradient-to-r from-indigo-50 to-white">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-indigo-600 text-white shrink-0"><LayoutTemplate className="w-5 h-5" /></div>
            <div className="min-w-0">
              <h2 className="font-bold text-slate-800 text-sm md:text-base">Dịch giữ định dạng</h2>
              <p className="text-[11px] text-slate-500 truncate">{fileName} · {translatedCount}/{numPages} trang đã dịch</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100 text-slate-500" title="Đóng">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-2 px-4 md:px-6 py-3 border-b border-slate-100">
          <label className="text-xs font-semibold text-slate-600">Trang:</label>
          <input
            value={rangeInput}
            onChange={e => setRangeInput(e.target.value)}
            disabled={running}
            placeholder={`VD: 1-3, 5 (1–${numPages})`}
            className="w-40 md:w-52 px-3 py-1.5 text-sm rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-300"
          />
          <button onClick={() => setRangeInput(String(selected))} disabled={running}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-50">Trang đang xem</button>
          <button onClick={() => setRangeInput(`1-${numPages}`)} disabled={running}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-50">Tất cả</button>

          {running ? (
            <button onClick={() => abortRef.current?.abort()}
              className="flex items-center gap-1.5 px-4 py-1.5 text-sm font-semibold rounded-lg bg-rose-600 text-white hover:bg-rose-700">
              <Square className="w-4 h-4" /> Dừng
            </button>
          ) : (
            <button onClick={handleStart} disabled={loadingCache}
              className="flex items-center gap-1.5 px-4 py-1.5 text-sm font-semibold rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50">
              <Play className="w-4 h-4" /> Dịch
            </button>
          )}

          <div className="flex-1" />

          <button onClick={() => handleExport('range')} disabled={exporting || running || translatedCount === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-semibold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 disabled:opacity-50"
            title="Xuất các trang đã dịch trong khoảng trang đang nhập">
            {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} Xuất PDF
          </button>
          <button onClick={() => handleExport('all')} disabled={exporting || running || translatedCount === 0}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-emerald-200 text-emerald-700 hover:bg-emerald-50 disabled:opacity-50"
            title="Xuất tất cả các trang đã dịch của tài liệu">
            Xuất tất cả đã dịch
          </button>
        </div>

        {running && (
          <div className="px-4 md:px-6 py-2 border-b border-slate-100 bg-indigo-50/50">
            <div className="flex justify-between text-[11px] text-indigo-700 mb-1">
              <span>Đang dịch trang {progress.page} ({progress.done + 1}/{progress.total})…</span>
              <span>{pct}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-indigo-100 overflow-hidden">
              <div className="h-full bg-indigo-600 transition-all" style={{ width: `${pct}%` }} />
            </div>
          </div>
        )}

        <div className="flex-1 flex flex-col md:flex-row min-h-0">
          {/* Page list */}
          <div className="md:w-28 shrink-0 border-b md:border-b-0 md:border-r border-slate-100 bg-slate-50/60 overflow-x-auto md:overflow-y-auto flex md:flex-col gap-1 p-2">
            {Array.from({ length: numPages }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setSelected(p)}
                className={`shrink-0 flex items-center justify-between gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${selected === p ? 'bg-indigo-600 text-white' : results[p] ? 'bg-white text-slate-700 hover:bg-indigo-50' : 'text-slate-400 hover:bg-white'}`}>
                <span>Tr. {p}</span>
                <span className={selected === p ? 'brightness-200' : ''}>{statusIcon(p)}</span>
              </button>
            ))}
          </div>

          {/* Viewer */}
          <div className="flex-1 flex flex-col min-h-0">
            <div className="flex flex-wrap items-center gap-2 px-3 py-2 border-b border-slate-100">
              <div className="flex items-center rounded-lg border border-slate-200 p-0.5">
                {([['translated', 'Bản dịch', ImageIcon], ['side', 'So sánh', Columns2], ['original', 'Bản gốc', FileText]] as const).map(([mode, label, Icon]) => (
                  <button key={mode} onClick={() => setViewMode(mode)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold ${viewMode === mode ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:bg-slate-100'}`}>
                    <Icon className="w-3.5 h-3.5" /> <span className="hidden sm:inline">{label}</span>
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => setSelected(s => Math.max(1, s - 1))} className="p-1.5 rounded hover:bg-slate-100"><ChevronLeft className="w-4 h-4" /></button>
                <span className="text-xs font-mono text-slate-600">{selected}/{numPages}</span>
                <button onClick={() => setSelected(s => Math.min(numPages, s + 1))} className="p-1.5 rounded hover:bg-slate-100"><ChevronRight className="w-4 h-4" /></button>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => setZoom(z => Math.max(0.5, +(z - 0.1).toFixed(2)))} className="p-1.5 rounded hover:bg-slate-100"><ZoomOut className="w-4 h-4" /></button>
                <span className="text-xs font-mono w-10 text-center">{Math.round(zoom * 100)}%</span>
                <button onClick={() => setZoom(z => Math.min(3, +(z + 0.1).toFixed(2)))} className="p-1.5 rounded hover:bg-slate-100"><ZoomIn className="w-4 h-4" /></button>
              </div>
              <div className="flex-1" />
              {current && !running && (
                <>
                  <button onClick={handleDownloadImage} className="px-2.5 py-1 text-xs rounded-lg border border-slate-200 hover:bg-slate-50">Tải ảnh trang</button>
                  <button onClick={handleRetranslate} className="flex items-center gap-1 px-2.5 py-1 text-xs rounded-lg border border-slate-200 hover:bg-slate-50">
                    <RefreshCw className="w-3.5 h-3.5" /> Dịch lại
                  </button>
                </>
              )}
            </div>

            {/* Page notice */}
            {(errors[selected] || current?.scanned || (current && current.overflowCount > 0)) && (
              <div className={`px-4 py-2 text-xs border-b ${errors[selected] ? 'bg-rose-50 text-rose-700 border-rose-100' : 'bg-amber-50 text-amber-800 border-amber-100'}`}>
                {errors[selected]
                  ? `Lỗi: ${errors[selected]}`
                  : current?.scanned
                    ? 'Trang này là ảnh scan (không có lớp chữ) nên chế độ giữ định dạng chưa hỗ trợ. Hãy dùng chế độ dịch thường cho trang này.'
                    : `${current!.overflowCount} khối chữ quá chật, đã thu nhỏ tối đa nhưng có thể lấn ra ngoài khung. Nên xem lại trang này.`}
              </div>
            )}

            <div className="flex-1 overflow-auto bg-slate-100 p-3 md:p-6">
              {viewMode === 'side' ? (
                <div className="grid grid-cols-2 gap-3 items-start" style={{ width: `${zoom * 100}%` }}>
                  <figure className="bg-white shadow rounded">
                    {originalUrl ? <img src={originalUrl} alt={`Trang gốc ${selected}`} className="w-full rounded" /> : <Placeholder text="Đang tải bản gốc…" />}
                    <figcaption className="text-[10px] text-center text-slate-400 py-1">Bản gốc</figcaption>
                  </figure>
                  <figure className="bg-white shadow rounded">
                    {currentUrl ? <img src={currentUrl} alt={`Trang dịch ${selected}`} className="w-full rounded" /> : <Placeholder text="Chưa dịch trang này" />}
                    <figcaption className="text-[10px] text-center text-slate-400 py-1">Bản dịch</figcaption>
                  </figure>
                </div>
              ) : viewMode === 'original' ? (
                <div className="mx-auto" style={imgStyle}>
                  {originalUrl ? <img src={originalUrl} alt={`Trang gốc ${selected}`} className="w-full bg-white shadow" /> : <Placeholder text="Đang tải bản gốc…" />}
                </div>
              ) : (
                <div className="mx-auto max-w-[1000px]" style={imgStyle}>
                  {currentUrl ? (
                    <img src={currentUrl} alt={`Trang dịch ${selected}`} className="w-full bg-white shadow select-none" draggable={false}
                      onContextMenu={e => e.preventDefault()} />
                  ) : (
                    <Placeholder text={loadingCache ? 'Đang tải…' : running && progress.page === selected ? 'Đang dịch trang này…' : 'Trang này chưa được dịch. Nhập số trang rồi bấm "Dịch".'} />
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="px-4 md:px-6 py-2 border-t border-slate-100 text-[10px] text-slate-400">
          Bản dịch được vẽ lại trên ảnh trang gốc (không sao chép chữ được). Chữ nằm bên trong hình ảnh và trang scan chưa được dịch ở chế độ này.
        </div>
      </div>
    </div>
  );
};

const Placeholder: React.FC<{ text: string }> = ({ text }) => (
  <div className="aspect-[1/1.414] w-full bg-white border border-dashed border-slate-300 rounded flex items-center justify-center text-sm text-slate-400 p-6 text-center">
    {text}
  </div>
);

export default LayoutTranslateModal;
