import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { 
  Folder, 
  FileText, 
  Plus, 
  FolderPlus, 
  Upload, 
  ChevronRight, 
  Home, 
  MoreVertical, 
  Trash2, 
  Move, 
  Download, 
  Edit,
  Loader2,
  Search,
  ArrowLeft,
  X,
  ArrowUpDown,
  SortAsc,
  SortDesc,
  Clock,
  Type,
  Share2,
  Users,
  Zap,
  HardDrive,
  Bot,
  BookOpen
} from 'lucide-react';
import { 
  db, 
  collection, 
  addDoc, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  onSnapshot, 
  deleteDoc, 
  updateDoc, 
  serverTimestamp,
  auth,
  OperationType,
  handleFirestoreError,
  collectionGroup
} from '../firebase';
import { cn } from '../../lib/utils.js';
import { motion, AnimatePresence } from 'motion/react';
import { saveAs } from 'file-saver';
import { downloadDriveFileAsArrayBuffer } from '../services/googleDriveService';

interface FolderData {
  id: string;
  name: string;
  parentId: string | null;
  createdAt: any;
}

export interface FileData {
  id: string;
  name: string;
  folderId: string | null;
  ownerId?: string;
  sharedWith?: string[];
  driveFileId?: string;
  token?: string;
  downloadUrl?: string;
  size: number;
  type: string;
  createdAt: any;
}

interface FileExplorerProps {
  onFileSelect: (file: FileData) => void;
  onUploadStart: (file: File, folderId: string | null) => void;
  onLocalFileOpen: (file: File) => void;
  onBulkTranslate?: (file: FileData) => void;
  onOpenGoogleDrive?: () => void;
  onAddToNotebook?: (file: FileData) => void;
}

export const FileExplorer: React.FC<FileExplorerProps> = ({ onFileSelect, onUploadStart, onLocalFileOpen, onBulkTranslate, onOpenGoogleDrive, onAddToNotebook }) => {
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'my' | 'shared'>('my');
  const [myFolders, setMyFolders] = useState<FolderData[]>([]);
  const [folders, setFolders] = useState<FolderData[]>([]);
  const [files, setFiles] = useState<FileData[]>([]);
  const [loading, setLoading] = useState(true);
  const [path, setPath] = useState<{id: string | null, name: string}[]>([{id: null, name: 'Root'}]);
  
  const [showNewFolderModal, setShowNewFolderModal] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  
  const [showRenameModal, setShowRenameModal] = useState<{id: string, name: string, type: 'file' | 'folder'} | null>(null);
  const [renameValue, setRenameValue] = useState('');

  const [showDeleteConfirm, setShowDeleteConfirm] = useState<{id: string, type: 'file' | 'folder', name: string} | null>(null);
  const [showShareModal, setShowShareModal] = useState<{id: string, type: 'file', name: string} | null>(null);
  const [shareEmail, setShareEmail] = useState('');
  const [isSharing, setIsSharing] = useState(false);
  
  const [showMoveModal, setShowMoveModal] = useState<{id: string, type: 'file' | 'folder'} | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'date' | 'size'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const [openingFileId, setOpeningFileId] = useState<string | null>(null);
  const [downloadingFileId, setDownloadingFileId] = useState<string | null>(null);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const [user, setUser] = useState<User | null>(() => auth.currentUser);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (!currentUser) {
        setLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  // Fetch my folders always for the move modal
  useEffect(() => {
    if (!user) {
      setMyFolders([]);
      return;
    }
    const q = query(collection(db, `users/${user.uid}/folders`), orderBy('name'));
    return onSnapshot(q, (snapshot) => {
      const folderList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as FolderData));
      setMyFolders(folderList);
    }, (error) => {
      console.error("Error fetching my folders:", error);
    });
  }, [user]);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);

    if (viewMode === 'my') {
      const foldersQuery = query(
        collection(db, `users/${user.uid}/folders`),
        where('parentId', '==', currentFolderId)
      );

      const filesQuery = query(
        collection(db, `users/${user.uid}/documents`),
        where('folderId', '==', currentFolderId)
      );

      const unsubscribeFolders = onSnapshot(foldersQuery, (snapshot) => {
        const folderList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as FolderData));
        setFolders(folderList);
        setLoading(false);
      }, (error) => {
        setLoading(false);
        handleFirestoreError(error, OperationType.GET, `users/${user.uid}/folders`);
      });

      const unsubscribeFiles = onSnapshot(filesQuery, (snapshot) => {
        const fileList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as FileData));
        setFiles(fileList);
        setLoading(false);
      }, (error) => {
        setLoading(false);
        handleFirestoreError(error, OperationType.GET, `users/${user.uid}/documents`);
      });

      return () => {
        unsubscribeFolders();
        unsubscribeFiles();
      };
    } else {
      // Shared mode - use collectionGroup to find files shared with this user's email
      setFolders([]); // We don't support sharing folders yet for simplicity
      const q = query(
        collectionGroup(db, 'documents'),
        where('sharedWith', 'array-contains', user.email)
      );

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const fileList = snapshot.docs.map(doc => {
          const data = doc.data();
          return { id: doc.id, ...data } as FileData;
        });
        setFiles(fileList);
        setLoading(false);
      }, (error) => {
        console.error("Error fetching shared files:", error);
        setLoading(false);
      });

      return unsubscribe;
    }
  }, [user, currentFolderId, viewMode]);

  // Reset opening state if folders change (e.g. navigation)
  useEffect(() => {
    setOpeningFileId(null);
  }, [currentFolderId]);

  const handleCreateFolder = async () => {
    const trimmed = newFolderName.trim();
    if (!trimmed) return;
    
    setIsCreatingFolder(true);
    try {
      if (user) {
        await addDoc(collection(db, `users/${user.uid}/folders`), {
          name: trimmed,
          parentId: currentFolderId,
          createdAt: serverTimestamp()
        });
      } else {
        const newFolder: FolderData = {
          id: 'local_' + Date.now(),
          name: trimmed,
          parentId: currentFolderId,
          createdAt: new Date()
        };
        setMyFolders(prev => [newFolder, ...prev]);
        setFolders(prev => [newFolder, ...prev]);
      }
    } catch (error) {
      console.error("Error creating folder:", error);
    } finally {
      setNewFolderName('');
      setShowNewFolderModal(false);
      setIsCreatingFolder(false);
    }
  };

  const handleLocalOpen = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    onLocalFileOpen(file);
    e.target.value = '';
  };

  const handleUploadFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    onUploadStart(file, currentFolderId);
    // Reset input
    e.target.value = '';
  };

  const handleDeleteItem = async () => {
    if (!user || !showDeleteConfirm) return;

    try {
      const collectionName = showDeleteConfirm.type === 'file' ? 'documents' : 'folders';
      const path = `users/${user.uid}/${collectionName}/${showDeleteConfirm.id}`;
      await deleteDoc(doc(db, `users/${user.uid}/${collectionName}`, showDeleteConfirm.id));
    } catch (error) {
      const collectionName = showDeleteConfirm.type === 'file' ? 'documents' : 'folders';
      handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/${collectionName}/${showDeleteConfirm.id}`);
    } finally {
      setShowDeleteConfirm(null);
    }
  };

  const handleRename = async () => {
    if (!user || !showRenameModal || !renameValue.trim()) return;

    try {
      const collectionName = showRenameModal.type === 'file' ? 'documents' : 'folders';
      const path = `users/${user.uid}/${collectionName}/${showRenameModal.id}`;
      await updateDoc(doc(db, `users/${user.uid}/${collectionName}`, showRenameModal.id), {
        name: renameValue.trim()
      });
      setShowRenameModal(null);
      setRenameValue('');
    } catch (error) {
      const collectionName = showRenameModal.type === 'file' ? 'documents' : 'folders';
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}/${collectionName}/${showRenameModal.id}`);
    }
  };

  const handleCloneSharedFile = async (file: FileData, targetFolderId: string | null) => {
    if (!user) return;
    setLoading(true);
    try {
      // 1. Create the document metadata in current user's collection
      const newDocRef = await addDoc(collection(db, `users/${user.uid}/documents`), {
        name: file.name,
        folderId: targetFolderId,
        ownerId: user.uid,
        token: file.token,
        downloadUrl: file.downloadUrl,
        size: file.size,
        type: file.type,
        createdAt: serverTimestamp(),
        clonedFrom: file.id // Reference to original
      });

      // 2. Copy the translations (pages)
      // Find the original owner path
      // Note: We need to know who the original owner was. 
      // The FileData should have ownerId.
      if (file.ownerId) {
        const pagesRef = collection(db, `users/${file.ownerId}/documents/${file.id}/pages`);
        const pagesSnap = await getDocs(pagesRef);
        
        for (const pageDoc of pagesSnap.docs) {
          await setDoc(doc(db, `users/${user.uid}/documents/${newDocRef.id}/pages`, pageDoc.id), pageDoc.data());
        }

        // Also copy summaries if any
        const summariesRef = collection(db, `users/${file.ownerId}/documents/${file.id}/summaries`);
        const summariesSnap = await getDocs(summariesRef);
        for (const sumDoc of summariesSnap.docs) {
          await addDoc(collection(db, `users/${user.uid}/documents/${newDocRef.id}/summaries`), sumDoc.data());
        }
      }

      setShowMoveModal(null);
      // Switch to 'my' view to see the result
      setViewMode('my');
      setCurrentFolderId(targetFolderId);
    } catch (error) {
      console.error("Error cloning shared file:", error);
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/documents`);
    } finally {
      setLoading(false);
    }
  };

  const handleMoveItem = async (targetFolderId: string | null) => {
    if (!user || !showMoveModal) return;

    if (viewMode === 'shared' && showMoveModal.type === 'file') {
      const fileToClone = files.find(f => f.id === showMoveModal.id);
      if (fileToClone) {
        await handleCloneSharedFile(fileToClone, targetFolderId);
      }
      return;
    }

    try {
      const collectionName = showMoveModal.type === 'file' ? 'documents' : 'folders';
      const path = `users/${user.uid}/${collectionName}/${showMoveModal.id}`;
      await updateDoc(doc(db, `users/${user.uid}/${collectionName}`, showMoveModal.id), {
        folderId: targetFolderId, // for files
        parentId: targetFolderId  // for folders
      });
      setShowMoveModal(null);
    } catch (error) {
      const collectionName = showMoveModal.type === 'file' ? 'documents' : 'folders';
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}/${collectionName}/${showMoveModal.id}`);
    }
  };

  const handleShare = async () => {
    if (!user || !showShareModal || !shareEmail.trim()) return;
    setIsSharing(true);
    try {
      const docRef = doc(db, `users/${user.uid}/documents`, showShareModal.id);
      
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const data = snap.data();
        const currentSharedWith = data.sharedWith || [];
        if (!currentSharedWith.includes(shareEmail.trim())) {
          await updateDoc(docRef, {
            sharedWith: [...currentSharedWith, shareEmail.trim()]
          });
        }
      }
      setShareEmail('');
      setShowShareModal(null);
    } catch (error: any) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}/documents/${showShareModal.id}`);
    } finally {
      setIsSharing(false);
    }
  };

  const navigateToFolder = async (folderId: string | null, folderName: string) => {
    if (folderId === null) {
      setPath([{id: null, name: 'Root'}]);
    } else {
      // Build path
      const newPath = [...path];
      const index = newPath.findIndex(p => p.id === folderId);
      if (index !== -1) {
        setPath(newPath.slice(0, index + 1));
      } else {
        setPath([...newPath, {id: folderId, name: folderName}]);
      }
    }
    setCurrentFolderId(folderId);
  };

  const sortedFolders = [...folders]
    .filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === 'name') {
        return sortOrder === 'asc' 
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      } else {
        // Default to date for folders if size is selected
        const dateA = a.createdAt?.toDate?.() || new Date(a.createdAt);
        const dateB = b.createdAt?.toDate?.() || new Date(b.createdAt);
        return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
      }
    });

  const sortedFiles = [...files]
    .filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === 'name') {
        return sortOrder === 'asc' 
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      } else if (sortBy === 'size') {
        return sortOrder === 'asc' ? a.size - b.size : b.size - a.size;
      } else {
        const dateA = a.createdAt?.toDate?.() || new Date(a.createdAt);
        const dateB = b.createdAt?.toDate?.() || new Date(b.createdAt);
        return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
      }
    });

  const toggleSort = (type: 'name' | 'date' | 'size') => {
    if (sortBy === type) {
      setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(type);
      setSortOrder(type === 'name' ? 'asc' : 'desc');
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
      {/* Header */}
      <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <div className="bg-indigo-600 p-2.5 rounded-2xl shadow-lg shadow-indigo-100">
            <Folder className="text-white w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-display font-bold text-slate-800">Quản lý tài liệu</h2>
            <div className="flex bg-slate-50 p-1 rounded-xl border border-slate-100 mt-2">
              <button 
                onClick={() => { setViewMode('my'); setCurrentFolderId(null); setPath([{id: null, name: 'Root'}]); }}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2",
                  viewMode === 'my' ? "bg-white shadow-sm text-indigo-600" : "text-slate-400 hover:text-slate-600"
                )}
              >
                <Home className="w-3.5 h-3.5" />
                Của tôi
              </button>
              <button 
                onClick={() => { setViewMode('shared'); setCurrentFolderId(null); setPath([{id: 'shared', name: 'Được chia sẻ'}]); }}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2",
                  viewMode === 'shared' ? "bg-white shadow-sm text-indigo-600" : "text-slate-400 hover:text-slate-600"
                )}
              >
                <Users className="w-3.5 h-3.5" />
                Được chia sẻ
              </button>
            </div>
            {viewMode === 'my' && (
              <div className="flex items-center gap-1 mt-2">
                {path.map((p, i) => (
                  <React.Fragment key={p.id || 'root'}>
                    <button 
                      onClick={() => navigateToFolder(p.id, p.name)}
                      className="text-[10px] font-bold text-slate-400 hover:text-indigo-600 transition-colors uppercase tracking-widest"
                    >
                      {p.name}
                    </button>
                    {i < path.length - 1 && <ChevronRight className="w-3 h-3 text-slate-300" />}
                  </React.Fragment>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative hidden sm:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Tìm kiếm..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all w-40"
            />
          </div>

          <div className="flex bg-slate-50 p-1 rounded-xl border border-slate-100">
            <button 
              onClick={() => toggleSort('name')}
              className={cn(
                "p-1.5 rounded-lg transition-all flex items-center gap-1",
                sortBy === 'name' ? "bg-white shadow-sm text-indigo-600" : "text-slate-400 hover:text-slate-600"
              )}
              title="Sắp xếp theo tên"
            >
              <Type className="w-4 h-4" />
              {sortBy === 'name' && (sortOrder === 'asc' ? <SortAsc className="w-3 h-3" /> : <SortDesc className="w-3 h-3" />)}
            </button>
            <button 
              onClick={() => toggleSort('date')}
              className={cn(
                "p-1.5 rounded-lg transition-all flex items-center gap-1",
                sortBy === 'date' ? "bg-white shadow-sm text-indigo-600" : "text-slate-400 hover:text-slate-600"
              )}
              title="Sắp xếp theo thời gian"
            >
              <Clock className="w-4 h-4" />
              {sortBy === 'date' && (sortOrder === 'asc' ? <SortAsc className="w-3 h-3" /> : <SortDesc className="w-3 h-3" />)}
            </button>
            <button 
              onClick={() => toggleSort('size')}
              className={cn(
                "p-1.5 rounded-lg transition-all flex items-center gap-1",
                sortBy === 'size' ? "bg-white shadow-sm text-indigo-600" : "text-slate-400 hover:text-slate-600"
              )}
              title="Sắp xếp theo dung lượng"
            >
              <ArrowUpDown className="w-4 h-4" />
              {sortBy === 'size' && (sortOrder === 'asc' ? <SortAsc className="w-3 h-3" /> : <SortDesc className="w-3 h-3" />)}
            </button>
          </div>

          {onOpenGoogleDrive && (
            <button 
              onClick={onOpenGoogleDrive}
              className="p-2.5 bg-indigo-50 border border-indigo-100 text-indigo-600 rounded-xl hover:bg-indigo-100 transition-all shadow-sm flex items-center gap-1.5"
              title="Mở hoặc chọn tài liệu từ Google Drive"
            >
              <HardDrive className="w-5 h-5" />
              <span className="text-xs font-bold hidden md:inline">Google Drive</span>
            </button>
          )}

          <button 
            onClick={() => setShowNewFolderModal(true)}
            className="p-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 transition-all shadow-sm"
            title="Tạo thư mục mới"
          >
            <FolderPlus className="w-5 h-5" />
          </button>
          
          <label className="p-2.5 bg-white border border-slate-200 text-indigo-600 rounded-xl hover:bg-slate-50 transition-all shadow-sm cursor-pointer" title="Mở tệp cục bộ (Không tải lên)">
            <FileText className="w-5 h-5" />
            <input type="file" className="hidden" accept=".pdf" onChange={handleLocalOpen} />
          </label>

          <label className="p-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 cursor-pointer" title="Tải lên đám mây">
            <Upload className="w-5 h-5" />
            <input type="file" className="hidden" accept=".pdf" onChange={handleUploadFile} />
          </label>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 no-scrollbar">
        {loading ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-400 gap-4">
            <Loader2 className="w-10 h-10 animate-spin text-indigo-500" />
            <p className="text-sm font-medium">Đang tải tài liệu...</p>
          </div>
        ) : (folders.length === 0 && files.length === 0) ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-300 gap-6">
            <div className="bg-slate-50 p-8 rounded-[40px] border border-slate-100">
              <Upload className="w-16 h-16 opacity-20" />
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-slate-400">Thư mục trống</p>
              <p className="text-sm">Tải lên file PDF hoặc tạo thư mục mới để bắt đầu</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {/* Folders */}
            {sortedFolders.map(folder => (
              <motion.div 
                key={folder.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="group relative bg-white border border-slate-100 rounded-2xl p-4 hover:border-indigo-200 hover:shadow-xl hover:shadow-indigo-50 transition-all cursor-pointer"
                onClick={() => navigateToFolder(folder.id, folder.name)}
              >
                <div className="flex flex-col items-center gap-3">
                  <div className="bg-amber-100 p-3 rounded-xl group-hover:bg-amber-200 transition-colors">
                    <Folder className="text-amber-600 w-8 h-8" />
                  </div>
                  <span className="text-xs font-bold text-slate-700 text-center truncate w-full">
                    {folder.name}
                  </span>
                </div>
                <div className="absolute top-2 right-2 flex flex-col gap-1 z-10">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveMenuId(activeMenuId === folder.id ? null : folder.id);
                    }}
                    className="p-1.5 bg-white rounded-lg text-slate-400 hover:text-indigo-500 shadow-sm border border-slate-100 flex items-center justify-center sm:opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <MoreVertical className="w-3.5 h-3.5" />
                  </button>
                  
                  <div className={cn(
                    "absolute right-0 top-full mt-2 w-44 bg-white rounded-2xl shadow-xl border border-slate-100 py-1.5 z-50 flex flex-col gap-0.5 transition-all origin-top-right",
                    activeMenuId === folder.id ? "opacity-100 scale-100" : "opacity-0 scale-95 pointer-events-none"
                  )}>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowMoveModal({ id: folder.id, type: 'folder' });
                        setActiveMenuId(null);
                      }}
                      className="w-full px-3.5 py-2 text-left text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 flex items-center gap-2.5 transition-colors"
                    >
                      <Move className="w-4 h-4 text-slate-400" />
                      <span>Di chuyển</span>
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setRenameValue(folder.name);
                        setShowRenameModal({ id: folder.id, name: folder.name, type: 'folder' });
                        setActiveMenuId(null);
                      }}
                      className="w-full px-3.5 py-2 text-left text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 flex items-center gap-2.5 transition-colors"
                    >
                      <Edit className="w-4 h-4 text-slate-400" />
                      <span>Đổi tên</span>
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowDeleteConfirm({ id: folder.id, type: 'folder', name: folder.name });
                        setActiveMenuId(null);
                      }}
                      className="w-full px-3.5 py-2 text-left text-xs font-bold text-rose-600 hover:bg-rose-50 flex items-center gap-2.5 transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-rose-500" />
                      <span>Xóa</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Files */}
            {sortedFiles.map(file => (
              <motion.div 
                key={file.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className={cn(
                  "group relative bg-white border border-slate-100 rounded-2xl p-4 hover:border-indigo-200 hover:shadow-xl hover:shadow-indigo-50 transition-all cursor-pointer",
                  openingFileId === file.id && "border-indigo-500 shadow-indigo-50 bg-indigo-50/30"
                )}
                onClick={() => {
                  if (openingFileId) return;
                  setOpeningFileId(file.id);
                  onFileSelect(file);
                }}
              >
                <div className="flex flex-col items-center gap-3">
                  <div className={cn(
                    "p-3 rounded-xl transition-colors",
                    openingFileId === file.id ? "bg-indigo-600" : "bg-indigo-50 group-hover:bg-indigo-100"
                  )}>
                    {openingFileId === file.id ? (
                      <Loader2 className="w-8 h-8 animate-spin text-white" />
                    ) : (
                      <FileText className="text-indigo-600 w-8 h-8" />
                    )}
                  </div>
                  <span className={cn(
                    "text-xs font-bold text-center truncate w-full",
                    openingFileId === file.id ? "text-indigo-700" : "text-slate-700"
                  )}>
                    {file.name}
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium">
                    {(file.size / 1024 / 1024).toFixed(2)} MB
                  </span>
                </div>
                <div className="absolute top-2 right-2 flex flex-col gap-1 z-10">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveMenuId(activeMenuId === file.id ? null : file.id);
                    }}
                    className="p-1.5 bg-white rounded-lg text-slate-400 hover:text-indigo-500 shadow-sm border border-slate-100 flex items-center justify-center sm:opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <MoreVertical className="w-3.5 h-3.5" />
                  </button>

                  <div className={cn(
                    "absolute right-0 top-full mt-2 w-48 bg-white rounded-2xl shadow-xl border border-slate-100 py-1.5 z-50 flex flex-col gap-0.5 transition-all origin-top-right",
                    activeMenuId === file.id ? "opacity-100 scale-100" : "opacity-0 scale-95 pointer-events-none"
                  )}>
                    {(file.driveFileId || file.downloadUrl) && (
                      <button 
                        onClick={async (e) => {
                          e.stopPropagation();
                          setDownloadingFileId(file.id);
                          try {
                            if (file.driveFileId) {
                              const buf = await downloadDriveFileAsArrayBuffer(file.driveFileId);
                              const blob = new Blob([buf], { type: 'application/pdf' });
                              saveAs(blob, file.name);
                            } else if (file.downloadUrl) {
                              const res = await fetch(file.downloadUrl);
                              const blob = await res.blob();
                              saveAs(blob, file.name);
                            }
                          } catch (err: any) {
                            console.error("Lỗi khi tải file:", err);
                            alert("Không thể tải file: " + (err.message || "Lỗi mạng"));
                          } finally {
                            setDownloadingFileId(null);
                            setActiveMenuId(null);
                          }
                        }}
                        disabled={downloadingFileId === file.id}
                        className="w-full px-3.5 py-2 text-left text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-emerald-600 flex items-center gap-2.5 transition-colors cursor-pointer disabled:opacity-50"
                        title="Tải trực tiếp file PDF về máy tính"
                      >
                        {downloadingFileId === file.id ? (
                          <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
                        ) : (
                          <Download className="w-4 h-4 text-emerald-600" />
                        )}
                        <span>{downloadingFileId === file.id ? "Đang tải về..." : "Tải về (PDF gốc)"}</span>
                      </button>
                    )}
                    {onBulkTranslate && viewMode === 'my' && (
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          onBulkTranslate(file);
                          setActiveMenuId(null);
                        }}
                        className="w-full px-3.5 py-2 text-left text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 flex items-center gap-2.5 transition-colors"
                      >
                        <Zap className="w-4 h-4 text-amber-500" />
                        <span>Dịch toàn bộ</span>
                      </button>
                    )}
                    {onAddToNotebook && (
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          onAddToNotebook(file);
                          setActiveMenuId(null);
                        }}
                        className="w-full px-3.5 py-2 text-left text-xs font-bold text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2.5 transition-colors cursor-pointer"
                        title="Thêm tài liệu này vào Notebook AI Workspace"
                      >
                        <Bot className="w-4 h-4 text-indigo-600" />
                        <span>Thêm vào Notebook AI</span>
                      </button>
                    )}
                    {viewMode === 'my' && (
                      <>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowShareModal({ id: file.id, type: 'file', name: file.name });
                            setActiveMenuId(null);
                          }}
                          className="w-full px-3.5 py-2 text-left text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 flex items-center gap-2.5 transition-colors"
                        >
                          <Share2 className="w-4 h-4 text-slate-400" />
                          <span>Chia sẻ</span>
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowMoveModal({ id: file.id, type: 'file' });
                            setActiveMenuId(null);
                          }}
                          className="w-full px-3.5 py-2 text-left text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 flex items-center gap-2.5 transition-colors"
                        >
                          <Move className="w-4 h-4 text-slate-400" />
                          <span>Di chuyển</span>
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setRenameValue(file.name);
                            setShowRenameModal({ id: file.id, name: file.name, type: 'file' });
                            setActiveMenuId(null);
                          }}
                          className="w-full px-3.5 py-2 text-left text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 flex items-center gap-2.5 transition-colors"
                        >
                          <Edit className="w-4 h-4 text-slate-400" />
                          <span>Đổi tên</span>
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowDeleteConfirm({ id: file.id, type: 'file', name: file.name });
                            setActiveMenuId(null);
                          }}
                          className="w-full px-3.5 py-2 text-left text-xs font-bold text-rose-600 hover:bg-rose-50 flex items-center gap-2.5 transition-colors"
                        >
                          <Trash2 className="w-4 h-4 text-rose-500" />
                          <span>Xóa</span>
                        </button>
                      </>
                    )}
                    {viewMode === 'shared' && (
                       <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowMoveModal({ id: file.id, type: 'file' });
                          setActiveMenuId(null);
                        }}
                        className="w-full px-3.5 py-2 text-left text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 flex items-center gap-2.5 transition-colors"
                      >
                        <Move className="w-4 h-4 text-slate-400" />
                        <span>Di chuyển về của tôi</span>
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Move Modal */}
      <AnimatePresence>
        {showMoveModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMoveModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-display font-bold text-slate-800">Di chuyển tới...</h3>
                <button onClick={() => setShowMoveModal(null)} className="p-2 hover:bg-slate-50 rounded-full transition-colors">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                <button 
                  onClick={() => handleMoveItem(null)}
                  className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 rounded-2xl transition-all text-left group"
                >
                  <div className="bg-slate-100 p-2 rounded-xl group-hover:bg-indigo-100 transition-colors">
                    <Home className="w-5 h-5 text-slate-500 group-hover:text-indigo-600" />
                  </div>
                  <span className="text-sm font-bold text-slate-700">Root</span>
                </button>
                {myFolders.filter(f => f.id !== showMoveModal.id).map(folder => (
                  <button 
                    key={folder.id}
                    onClick={() => handleMoveItem(folder.id)}
                    className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 rounded-2xl transition-all text-left group"
                  >
                    <div className="bg-amber-50 p-2 rounded-xl group-hover:bg-amber-100 transition-colors">
                      <Folder className="w-5 h-5 text-amber-600" />
                    </div>
                    <span className="text-sm font-bold text-slate-700">{folder.name}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Rename Modal */}
      <AnimatePresence>
        {showRenameModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowRenameModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden p-8"
            >
              <h3 className="text-xl font-display font-bold text-slate-800 mb-6">Đổi tên {showRenameModal.type === 'file' ? 'tệp' : 'thư mục'}</h3>
              <input 
                type="text" 
                placeholder="Tên mới" 
                value={renameValue}
                onChange={(e) => setRenameValue(e.target.value)}
                autoFocus
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm mb-6"
              />
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowRenameModal(null)}
                  className="flex-1 px-6 py-3 rounded-xl text-sm font-bold text-slate-500 hover:bg-slate-100 transition-colors"
                >
                  Hủy
                </button>
                <button 
                  onClick={handleRename}
                  className="flex-1 px-6 py-3 rounded-xl text-sm font-bold bg-indigo-600 text-white hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
                >
                  Lưu
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDeleteConfirm(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden p-8"
            >
              <div className="bg-rose-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                <Trash2 className="w-8 h-8 text-rose-500" />
              </div>
              <h3 className="text-xl font-display font-bold text-slate-800 mb-2 text-center">Xác nhận xóa?</h3>
              <p className="text-slate-500 text-sm text-center mb-8">
                Bạn có chắc chắn muốn xóa {showDeleteConfirm.type === 'file' ? 'tệp' : 'thư mục'} <span className="font-bold text-slate-700">"{showDeleteConfirm.name}"</span>? Hành động này không thể hoàn tác.
              </p>
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowDeleteConfirm(null)}
                  className="flex-1 px-6 py-3 rounded-xl text-sm font-bold text-slate-500 hover:bg-slate-100 transition-colors"
                >
                  Hủy
                </button>
                <button 
                  onClick={handleDeleteItem}
                  className="flex-1 px-6 py-3 rounded-xl text-sm font-bold bg-rose-500 text-white hover:bg-rose-600 transition-all shadow-lg shadow-rose-100"
                >
                  Xóa ngay
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Share Modal */}
      <AnimatePresence>
        {showShareModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowShareModal(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden p-8"
            >
              <div className="bg-indigo-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                <Share2 className="w-8 h-8 text-indigo-500" />
              </div>
              <h3 className="text-xl font-display font-bold text-slate-800 mb-2 text-center">Chia sẻ tài liệu</h3>
              <p className="text-slate-500 text-sm text-center mb-6">
                Chia sẻ <span className="font-bold text-slate-700">"{showShareModal.name}"</span> với người dùng khác qua email.
              </p>
              
              <div className="space-y-4 mb-8">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Email người nhận</label>
                  <input 
                    type="email" 
                    placeholder="example@gmail.com" 
                    value={shareEmail}
                    onChange={(e) => setShareEmail(e.target.value)}
                    autoFocus
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm"
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => setShowShareModal(null)}
                  className="flex-1 px-6 py-3 rounded-xl text-sm font-bold text-slate-500 hover:bg-slate-100 transition-colors"
                >
                  Hủy
                </button>
                <button 
                  onClick={handleShare}
                  disabled={isSharing || !shareEmail.trim()}
                  className="flex-1 px-6 py-3 rounded-xl text-sm font-bold bg-indigo-600 text-white hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSharing && <Loader2 className="w-4 h-4 animate-spin" />}
                  Chia sẻ ngay
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* New Folder Modal */}
      <AnimatePresence>
        {showNewFolderModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setShowNewFolderModal(false);
                setNewFolderName('');
              }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.form 
              onSubmit={(e) => {
                e.preventDefault();
                handleCreateFolder();
              }}
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden p-8"
            >
              <h3 className="text-xl font-display font-bold text-slate-800 mb-6">Tạo thư mục mới</h3>
              <input 
                type="text" 
                placeholder="Tên thư mục" 
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                autoFocus
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm mb-6"
              />
              <div className="flex gap-3">
                <button 
                  type="button"
                  onClick={() => {
                    setShowNewFolderModal(false);
                    setNewFolderName('');
                  }}
                  className="flex-1 px-6 py-3 rounded-xl text-sm font-bold text-slate-500 hover:bg-slate-100 transition-colors"
                >
                  Hủy
                </button>
                <button 
                  type="submit"
                  disabled={isCreatingFolder || !newFolderName.trim()}
                  className="flex-1 px-6 py-3 rounded-xl text-sm font-bold bg-indigo-600 text-white hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isCreatingFolder ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    'Tạo mới'
                  )}
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
