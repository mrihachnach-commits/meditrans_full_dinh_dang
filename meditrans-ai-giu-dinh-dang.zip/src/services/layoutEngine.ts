/**
 * MediTrans AI — Layout Engine (dịch giữ định dạng, xuất dạng ảnh)
 *
 * Module thuần (không phụ thuộc React / pdf.js / Firebase):
 *  1. buildBlocks(): gom các text item của pdf.js thành dòng → khối (đoạn văn, tiêu đề, ô bảng, chú thích).
 *  2. paintTranslatedPage(): trên canvas đã render trang gốc, xoá chữ gốc bằng màu nền lấy mẫu thật
 *     và vẽ bản dịch tiếng Việt vừa khung (ngắt dòng → giảm giãn dòng → giảm cỡ chữ, KHÔNG cắt bỏ chữ).
 *
 * Mọi toạ độ trong module là toạ độ pixel của canvas (gốc trên-trái, y hướng xuống).
 */

export interface RawTextItem {
  str: string;
  transform: number[]; // [a, b, c, d, e, f] trong không gian PDF
  width: number;       // độ rộng trong không gian PDF
  fontName: string;
}

export interface FontStyleInfo {
  bold: boolean;
  italic: boolean;
  serif: boolean;
}

interface NormItem {
  str: string;
  x: number;      // mép trái
  y: number;      // baseline
  size: number;   // cỡ chữ (px)
  w: number;      // độ rộng (px)
  bold: boolean;
  italic: boolean;
  serif: boolean;
}

interface Segment {
  text: string;
  x0: number;
  x1: number;
  y: number;     // baseline
  size: number;
  bold: boolean;
  italic: boolean;
  serif: boolean;
}

export type BlockAlign = 'left' | 'center' | 'justify';

export interface LayoutBlock {
  id: string;
  text: string;
  x0: number;
  x1: number;
  top: number;
  bottom: number;
  size: number;
  leading: number;     // khoảng cách baseline (px)
  lineCount: number;
  bold: boolean;
  italic: boolean;
  serif: boolean;
  align: BlockAlign;
  translatable: boolean;
}

export interface PaintReport {
  painted: number;
  overflowIds: string[];
  shrunkIds: string[];
}

/* ------------------------------------------------------------------ */
/* Tiện ích                                                            */
/* ------------------------------------------------------------------ */

function mul(m1: number[], m2: number[]): number[] {
  return [
    m1[0] * m2[0] + m1[2] * m2[1],
    m1[1] * m2[0] + m1[3] * m2[1],
    m1[0] * m2[2] + m1[2] * m2[3],
    m1[1] * m2[2] + m1[3] * m2[3],
    m1[0] * m2[4] + m1[2] * m2[5] + m1[4],
    m1[1] * m2[4] + m1[3] * m2[5] + m1[5],
  ];
}

function median(values: number[]): number {
  if (values.length === 0) return 0;
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

const SUPERSCRIPT_MAP: Record<string, string> = {
  '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹',
  '+': '⁺', '-': '⁻', '–': '⁻', '=': '⁼', '(': '⁽', ')': '⁾', 'n': 'ⁿ', 'i': 'ⁱ',
};

function toSuperscript(s: string): string {
  // Chỉ chuyển nếu mọi ký tự (trừ dấu phẩy/khoảng trắng) đều có dạng superscript
  const core = s.replace(/[,\s]/g, '');
  if (!core || [...core].some(ch => !SUPERSCRIPT_MAP[ch])) return s;
  return [...s].map(ch => SUPERSCRIPT_MAP[ch] ?? ch).join('');
}

/** Khối có đáng dịch không (có chữ cái, không chỉ là số trang/URL/DOI/email). */
function isTranslatableText(text: string): boolean {
  const t = text.trim();
  if (!t) return false;
  const letters = t.match(/\p{L}/gu)?.length ?? 0;
  if (letters < 2) return false;
  if (/^(https?:\/\/|www\.)\S+$/i.test(t)) return false;
  if (/^(doi:?\s*)?10\.\d{4,}\/\S+$/i.test(t)) return false;
  if (/^\S+@\S+\.\S+$/.test(t)) return false;
  if (/^(page|trang)?\s*\d+(\s*(of|\/)\s*\d+)?$/i.test(t)) return false;
  return true;
}

/* ------------------------------------------------------------------ */
/* 1. Gom text item → dòng → khối                                      */
/* ------------------------------------------------------------------ */

export function normalizeItems(
  items: RawTextItem[],
  viewportTransform: number[],
  getStyle: (fontName: string) => FontStyleInfo,
): NormItem[] {
  const scale = Math.hypot(viewportTransform[0], viewportTransform[1]);
  const out: NormItem[] = [];
  for (const it of items) {
    if (!it.str || !it.str.trim()) continue;
    const m = mul(viewportTransform, it.transform);
    const size = Math.hypot(m[2], m[3]);
    if (!isFinite(size) || size < 2) continue;
    // Bỏ qua chữ xoay / chữ dọc — giữ nguyên trên ảnh gốc
    if (Math.abs(m[1]) > 0.05 * Math.abs(m[0]) || m[0] <= 0) continue;
    const st = getStyle(it.fontName);
    out.push({
      str: it.str,
      x: m[4],
      y: m[5],
      size,
      w: Math.max(0, it.width * scale),
      bold: st.bold,
      italic: st.italic,
      serif: st.serif,
    });
  }
  return out;
}

function buildSegments(items: NormItem[]): Segment[] {
  const sorted = [...items].sort((a, b) => a.y - b.y || a.x - b.x);

  // Gom theo hàng (baseline gần nhau)
  const rows: NormItem[][] = [];
  for (const it of sorted) {
    let placed = false;
    for (let r = rows.length - 1; r >= 0 && r >= rows.length - 4; r--) {
      const row = rows[r];
      const ref = row.reduce((a, b) => (b.size > a.size ? b : a));
      const tol = 0.5 * Math.max(ref.size, it.size);
      if (Math.abs(it.y - ref.y) < tol) {
        row.push(it);
        placed = true;
        break;
      }
    }
    if (!placed) rows.push([it]);
  }

  const segments: Segment[] = [];
  for (const row of rows) {
    row.sort((a, b) => a.x - b.x);
    const mainSize = median(row.map(r => r.size));
    let cur: NormItem[] = [];
    const flush = () => {
      if (cur.length === 0) return;
      segments.push(makeSegment(cur));
      cur = [];
    };
    for (const it of row) {
      if (cur.length) {
        const prev = cur[cur.length - 1];
        const gap = it.x - (prev.x + prev.w);
        if (gap > 1.2 * mainSize) flush();
      }
      cur.push(it);
    }
    flush();
  }
  return attachOrphanSuperscripts(segments);
}

/**
 * Chỉ số trích dẫn (¹, ²³…) đôi khi bị tách thành đoạn riêng do lệch baseline.
 * Gắn chúng vào đoạn chữ ngay bên trái trên cùng dòng.
 */
function attachOrphanSuperscripts(segments: Segment[]): Segment[] {
  const orphan = (s: Segment) => /^[\d,–\-\s]{1,8}$/.test(s.text);
  const result = segments.filter(s => !orphan(s));
  for (const sup of segments.filter(orphan)) {
    const host = result.find(h =>
      sup.size < 0.88 * h.size &&
      Math.abs(sup.x0 - h.x1) < 0.6 * h.size &&
      sup.y < h.y - 0.1 * h.size &&
      sup.y > h.y - 0.8 * h.size,
    );
    if (host) {
      host.text += toSuperscript(sup.text.replace(/\s+/g, ''));
      host.x1 = Math.max(host.x1, sup.x1);
    } else {
      result.push(sup);
    }
  }
  return result;
}

function makeSegment(items: NormItem[]): Segment {
  // Cỡ chữ chủ đạo = cỡ có nhiều ký tự nhất
  const sizeWeight = new Map<number, number>();
  for (const it of items) {
    const k = Math.round(it.size * 2) / 2;
    sizeWeight.set(k, (sizeWeight.get(k) || 0) + it.str.length);
  }
  let size = items[0].size;
  let best = -1;
  sizeWeight.forEach((w, k) => { if (w > best) { best = w; size = k; } });

  const main = items.filter(i => Math.abs(i.size - size) < 0.6);
  const baseline = median((main.length ? main : items).map(i => i.y));

  let text = '';
  let prevEnd = -Infinity;
  for (const it of items) {
    let piece = it.str;
    const isSup = it.size < 0.82 * size && it.y < baseline - 0.15 * size;
    if (isSup) piece = toSuperscript(piece);
    if (text) {
      const gap = it.x - prevEnd;
      if (gap > 0.12 * size && !/\s$/.test(text) && !/^\s/.test(piece) && !isSup) text += ' ';
    }
    text += piece;
    prevEnd = it.x + it.w;
  }

  const chars = (f: (i: NormItem) => boolean) =>
    items.filter(f).reduce((s, i) => s + i.str.length, 0);
  const total = Math.max(1, chars(() => true));

  return {
    text: text.replace(/\s+/g, ' ').trim(),
    x0: Math.min(...items.map(i => i.x)),
    x1: Math.max(...items.map(i => i.x + i.w)),
    y: baseline,
    size,
    bold: chars(i => i.bold) / total > 0.6,
    italic: chars(i => i.italic) / total > 0.6,
    serif: chars(i => i.serif) / total >= 0.5,
  };
}

interface WorkBlock {
  lines: Segment[];
  x0: number;
  x1: number;
  size: number;
  bold: boolean;
}

export function buildBlocks(items: NormItem[], pageWidth: number): LayoutBlock[] {
  const segments = buildSegments(items).filter(s => s.text.length > 0);
  segments.sort((a, b) => a.y - b.y || a.x0 - b.x0);

  const work: WorkBlock[] = [];

  for (const seg of segments) {
    let bestBlock: WorkBlock | null = null;
    let bestGap = Infinity;

    for (const b of work) {
      const last = b.lines[b.lines.length - 1];
      if (Math.abs(seg.size - b.size) > 0.12 * b.size) continue;
      if (seg.bold !== b.bold) continue;

      const gap = seg.y - last.y;
      if (gap < 0.5 * b.size || gap > 1.75 * b.size) continue;
      if (b.lines.length >= 2) {
        const lead = b.lines[b.lines.length - 1].y - b.lines[b.lines.length - 2].y;
        if (Math.abs(gap - lead) > 0.3 * lead) continue;
      }

      const overlap = Math.min(seg.x1, b.x1) - Math.max(seg.x0, b.x0);
      const minW = Math.min(seg.x1 - seg.x0, b.x1 - b.x0);
      if (overlap < 0.5 * minW) continue;

      const leftAligned = Math.abs(seg.x0 - b.x0) < 2.5 * b.size;
      const centered = Math.abs((seg.x0 + seg.x1) / 2 - (b.x0 + b.x1) / 2) < b.size;
      if (!leftAligned && !centered) continue;

      // Ngắt đoạn: dòng trước kết thúc sớm (dòng cuối đoạn) hoặc dòng mới thụt đầu dòng
      const blockWidth = b.x1 - b.x0;
      const prevShort = b.lines.length >= 2 && last.x1 < b.x1 - Math.max(3 * b.size, 0.15 * blockWidth);
      const indentStart = seg.x0 > b.x0 + 0.8 * b.size && seg.x1 > b.x1 - 1.5 * b.size && b.lines.length >= 2;
      if ((prevShort && !centered) || indentStart) continue;

      if (gap < bestGap) {
        bestGap = gap;
        bestBlock = b;
      }
    }

    if (bestBlock) {
      bestBlock.lines.push(seg);
      bestBlock.x0 = Math.min(bestBlock.x0, seg.x0);
      bestBlock.x1 = Math.max(bestBlock.x1, seg.x1);
    } else {
      work.push({ lines: [seg], x0: seg.x0, x1: seg.x1, size: seg.size, bold: seg.bold });
    }
  }

  const blocks: LayoutBlock[] = work.map((b, idx) => {
    const lines = b.lines;
    const first = lines[0];
    const last = lines[lines.length - 1];
    const gaps = lines.slice(1).map((l, i) => l.y - lines[i].y);
    const leading = gaps.length ? median(gaps) : b.size * 1.2;

    let text = '';
    for (const l of lines) {
      if (!text) { text = l.text; continue; }
      if (/\p{L}-$/u.test(text) && /^\p{Ll}/u.test(l.text)) {
        text = text.slice(0, -1) + l.text; // nối từ bị gạch nối cuối dòng
      } else {
        text += ' ' + l.text;
      }
    }

    const width = b.x1 - b.x0;
    let align: BlockAlign = 'left';
    if (lines.length >= 3) {
      const body = lines.slice(0, -1);
      const full = body.filter(l => l.x1 >= b.x1 - 0.6 * b.size && l.x0 <= b.x0 + 1.2 * b.size).length;
      if (full / body.length >= 0.7) align = 'justify';
    }
    if (align === 'left' && lines.length >= 2) {
      const center = (b.x0 + b.x1) / 2;
      const allCentered = lines.every(l => Math.abs((l.x0 + l.x1) / 2 - center) < 0.6 * b.size);
      const someShorter = lines.some(l => l.x1 - l.x0 < width - 2 * b.size);
      if (allCentered && someShorter) align = 'center';
    }
    if (align === 'left' && lines.length === 1 && b.bold) {
      const center = (b.x0 + b.x1) / 2;
      if (Math.abs(center - pageWidth / 2) < 0.02 * pageWidth && width < 0.8 * pageWidth) align = 'center';
    }

    const count = (f: (s: Segment) => boolean) => lines.filter(f).length / lines.length;

    return {
      id: `b${idx + 1}`,
      text,
      x0: b.x0,
      x1: b.x1,
      top: first.y - 0.9 * b.size,
      bottom: last.y + 0.28 * b.size,
      size: b.size,
      leading,
      lineCount: lines.length,
      bold: b.bold,
      italic: count(s => s.italic) > 0.5,
      serif: count(s => s.serif) >= 0.5,
      align,
      translatable: isTranslatableText(text),
    };
  });

  return orderForReading(blocks, pageWidth);
}

/** Sắp xếp theo thứ tự đọc (hỗ trợ 2 cột) để bản dịch có ngữ cảnh liền mạch. */
function orderForReading(blocks: LayoutBlock[], pageWidth: number): LayoutBlock[] {
  const isFull = (b: LayoutBlock) => b.x1 - b.x0 > 0.6 * pageWidth;
  const byTop = [...blocks].sort((a, b) => a.top - b.top);
  const result: LayoutBlock[] = [];
  let band: LayoutBlock[] = [];
  const flushBand = () => {
    const left = band.filter(b => (b.x0 + b.x1) / 2 < pageWidth / 2).sort((a, b) => a.top - b.top);
    const right = band.filter(b => (b.x0 + b.x1) / 2 >= pageWidth / 2).sort((a, b) => a.top - b.top);
    result.push(...left, ...right);
    band = [];
  };
  for (const b of byTop) {
    if (isFull(b)) {
      flushBand();
      result.push(b);
    } else {
      band.push(b);
    }
  }
  flushBand();
  return result.map((b, i) => ({ ...b, id: `b${i + 1}` }));
}

/* ------------------------------------------------------------------ */
/* 2. Vẽ bản dịch lên canvas                                           */
/* ------------------------------------------------------------------ */

export const SERIF_STACK = '"Tinos", "Liberation Serif", "Times New Roman", Times, serif';
export const SANS_STACK = '"Arimo", "Liberation Sans", Arial, Helvetica, sans-serif';

function fontFor(b: LayoutBlock, sizePx: number): string {
  return `${b.italic ? 'italic ' : ''}${b.bold ? '700' : '400'} ${sizePx.toFixed(2)}px ${b.serif ? SERIF_STACK : SANS_STACK}`;
}

interface RGB { r: number; g: number; b: number; }

function colorDist(a: RGB, b: RGB) {
  return Math.abs(a.r - b.r) + Math.abs(a.g - b.g) + Math.abs(a.b - b.b);
}

function analyzeRegion(data: Uint8ClampedArray): { bg: RGB; uniform: number; fg: RGB | null } {
  const bins = new Map<number, { n: number; r: number; g: number; b: number }>();
  const total = data.length / 4;
  for (let i = 0; i < data.length; i += 4) {
    const key = ((data[i] >> 4) << 8) | ((data[i + 1] >> 4) << 4) | (data[i + 2] >> 4);
    const e = bins.get(key) || { n: 0, r: 0, g: 0, b: 0 };
    e.n++; e.r += data[i]; e.g += data[i + 1]; e.b += data[i + 2];
    bins.set(key, e);
  }
  let mode = { n: 0, r: 255, g: 255, b: 255 };
  bins.forEach(e => { if (e.n > mode.n) mode = e; });
  const bg: RGB = mode.n ? { r: mode.r / mode.n, g: mode.g / mode.n, b: mode.b / mode.n } : { r: 255, g: 255, b: 255 };

  let near = 0;
  const fgR: number[] = [], fgG: number[] = [], fgB: number[] = [];
  for (let i = 0; i < data.length; i += 4) {
    const p = { r: data[i], g: data[i + 1], b: data[i + 2] };
    const d = colorDist(p, bg);
    if (d < 40) near++;
    else if (d > 150) { fgR.push(p.r); fgG.push(p.g); fgB.push(p.b); }
  }
  const fg = fgR.length > total * 0.01 ? { r: median(fgR), g: median(fgG), b: median(fgB) } : null;
  return { bg, uniform: near / Math.max(1, total), fg };
}

function rgbCss(c: RGB, a = 1) {
  return `rgba(${Math.round(c.r)}, ${Math.round(c.g)}, ${Math.round(c.b)}, ${a})`;
}

/** Tính khoảng trống phía dưới khối (chỉ những hàng pixel còn đúng màu nền) để bản dịch dài hơn có chỗ giãn. */
function measureFreeSpaceBelow(
  ctx: CanvasRenderingContext2D,
  b: LayoutBlock,
  bg: RGB,
  limitY: number,
): number {
  const x = Math.max(0, Math.floor(b.x0));
  const w = Math.max(1, Math.ceil(b.x1 - b.x0));
  const startY = Math.ceil(b.bottom + 1);
  const maxY = Math.min(Math.floor(limitY), ctx.canvas.height - 1);
  if (startY >= maxY) return 0;
  const h = maxY - startY;
  const img = ctx.getImageData(x, startY, w, h).data;
  for (let row = 0; row < h; row++) {
    let off = 0;
    for (let col = 0; col < w; col += 2) {
      const i = (row * w + col) * 4;
      if (Math.abs(img[i] - bg.r) + Math.abs(img[i + 1] - bg.g) + Math.abs(img[i + 2] - bg.b) > 45) off++;
    }
    if (off > 0) return Math.max(0, row - 3);
  }
  return h;
}

/** Khoảng trống bên phải (và bên trái nếu căn giữa) của khối 1 dòng: chỉ tính phần pixel còn đúng màu nền. */
function measureFreeSpaceSide(
  ctx: CanvasRenderingContext2D,
  b: LayoutBlock,
  bg: RGB,
  fromX: number,
  toX: number,
): number {
  const dir = toX >= fromX ? 1 : -1;
  const span = Math.floor(Math.abs(toX - fromX));
  if (span <= 0) return 0;
  const y = Math.max(0, Math.floor(b.top));
  const h = Math.max(1, Math.min(ctx.canvas.height - y, Math.ceil(b.bottom - b.top)));
  const x = dir > 0 ? Math.ceil(fromX) : Math.floor(fromX) - span;
  const sx = Math.max(0, x);
  const w = Math.min(ctx.canvas.width - sx, span);
  if (w <= 0) return 0;
  const img = ctx.getImageData(sx, y, w, h).data;
  for (let k = 0; k < w; k++) {
    const col = dir > 0 ? k : w - 1 - k;
    for (let row = 0; row < h; row += 2) {
      const i = (row * w + col) * 4;
      if (Math.abs(img[i] - bg.r) + Math.abs(img[i + 1] - bg.g) + Math.abs(img[i + 2] - bg.b) > 45) {
        return Math.max(0, k - 0.5 * b.size);
      }
    }
  }
  return w;
}

function wrapWords(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let line = '';
  for (const word of words) {
    const candidate = line ? `${line} ${word}` : word;
    if (ctx.measureText(candidate).width <= maxWidth || !line) {
      if (!line && ctx.measureText(word).width > maxWidth) {
        // Từ quá dài (URL, chuỗi hoá chất…) → bẻ theo ký tự
        let part = '';
        for (const ch of word) {
          if (ctx.measureText(part + ch).width > maxWidth && part) {
            lines.push(part);
            part = ch;
          } else {
            part += ch;
          }
        }
        line = part;
      } else {
        line = candidate;
      }
    } else {
      lines.push(line);
      line = word;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function drawLine(
  ctx: CanvasRenderingContext2D,
  line: string,
  x0: number,
  width: number,
  y: number,
  align: BlockAlign,
  isLast: boolean,
  sizePx: number,
) {
  if (align === 'center') {
    const w = ctx.measureText(line).width;
    ctx.fillText(line, x0 + (width - w) / 2, y);
    return;
  }
  if (align === 'justify' && !isLast) {
    const words = line.split(' ');
    if (words.length > 1) {
      const wordsW = words.reduce((s, w) => s + ctx.measureText(w).width, 0);
      const gap = (width - wordsW) / (words.length - 1);
      const normalGap = ctx.measureText(' ').width;
      if (gap > normalGap * 0.8 && gap < sizePx * 0.9) {
        let x = x0;
        for (const w of words) {
          ctx.fillText(w, x, y);
          x += ctx.measureText(w).width + gap;
        }
        return;
      }
    }
  }
  ctx.fillText(line, x0, y);
}

/**
 * Vẽ bản dịch lên canvas đã render trang gốc.
 * translations: map id khối → bản dịch. Khối không có bản dịch được giữ nguyên.
 */
export function paintTranslatedPage(
  ctx: CanvasRenderingContext2D,
  blocks: LayoutBlock[],
  translations: Record<string, string>,
): PaintReport {
  const report: PaintReport = { painted: 0, overflowIds: [], shrunkIds: [] };
  const canvasH = ctx.canvas.height;
  const canvasW = ctx.canvas.width;
  const safeBottom = canvasH * 0.985;

  const norm = (t: string) => t.replace(/\s+/g, ' ').trim();
  const targets = blocks.filter(
    b => b.translatable && translations[b.id] && norm(translations[b.id]) && norm(translations[b.id]) !== norm(b.text),
  );

  // Bước 1: phân tích màu nền / màu chữ cho tất cả khối TRƯỚC khi xoá (để không lấy mẫu nhầm vùng đã vẽ lại)
  const info = new Map<string, { bg: RGB; fg: RGB | null; uniform: number; free: number; extLeft: number; extRight: number }>();
  for (const b of targets) {
    const padX = 0.15 * b.size;
    const rx = Math.max(0, Math.floor(b.x0 - padX));
    const ry = Math.max(0, Math.floor(b.top - 0.05 * b.size));
    const rw = Math.min(canvasW - rx, Math.ceil(b.x1 - b.x0 + 2 * padX));
    const rh = Math.min(canvasH - ry, Math.ceil(b.bottom - b.top + 0.15 * b.size));
    if (rw <= 0 || rh <= 0) continue;
    const a = analyzeRegion(ctx.getImageData(rx, ry, rw, rh).data);

    // Giới hạn giãn xuống: tới khối chữ kế tiếp nằm bên dưới có giao theo chiều ngang
    let limit = safeBottom;
    for (const o of blocks) {
      if (o === b || o.top <= b.bottom - 1) continue;
      const overlap = Math.min(o.x1, b.x1) - Math.max(o.x0, b.x0);
      if (overlap > 0 && o.top < limit) limit = o.top - 0.15 * o.size;
    }
    const free = measureFreeSpaceBelow(ctx, b, a.bg, limit);

    // Khối 1 dòng (tiêu đề, nhãn, ô bảng): cho phép giãn ngang tới mép cột / ô kế bên
    let extLeft = 0;
    let extRight = 0;
    if (b.lineCount === 1) {
      let right = canvasW * 0.96;
      let left = canvasW * 0.04;
      // Mép cột = mép phải/trái của các đoạn văn nhiều dòng cùng cột
      const colBlocks = blocks.filter(o => o !== b && o.lineCount >= 2 && o.x0 < b.x1 && o.x1 > b.x0);
      if (colBlocks.length) {
        right = Math.min(right, Math.max(...colBlocks.map(o => o.x1)));
        left = Math.max(left, Math.min(...colBlocks.map(o => o.x0)));
      }
      // Không lấn sang khối cùng hàng
      for (const o of blocks) {
        if (o === b || o.top >= b.bottom || o.bottom <= b.top) continue;
        if (o.x0 >= b.x1 - 1) right = Math.min(right, o.x0 - 0.8 * b.size);
        if (o.x1 <= b.x0 + 1) left = Math.max(left, o.x1 + 0.8 * b.size);
      }
      extRight = right > b.x1 ? measureFreeSpaceSide(ctx, b, a.bg, b.x1 + 0.15 * b.size, right) : 0;
      if (b.align === 'center') {
        const extL = left < b.x0 ? measureFreeSpaceSide(ctx, b, a.bg, b.x0 - 0.15 * b.size, left) : 0;
        const both = Math.min(extL, extRight);
        extLeft = both;
        extRight = both;
      }
    }
    info.set(b.id, { ...a, free, extLeft, extRight });
  }

  // Bước 2: xoá chữ gốc
  for (const b of targets) {
    const inf = info.get(b.id);
    if (!inf) continue;
    const padX = 0.15 * b.size;
    ctx.save();
    ctx.fillStyle = rgbCss(inf.bg, inf.uniform >= 0.45 ? 1 : 0.93);
    ctx.fillRect(b.x0 - padX, b.top - 0.05 * b.size, b.x1 - b.x0 + 2 * padX, b.bottom - b.top + 0.15 * b.size);
    ctx.restore();
  }

  // Bước 3: vẽ bản dịch
  for (const b of targets) {
    const inf = info.get(b.id);
    if (!inf) continue;
    const text = translations[b.id].replace(/\s+/g, ' ').trim();
    const x0 = b.x0 - inf.extLeft;
    const width = Math.max(b.x1 - b.x0 + inf.extLeft + inf.extRight, b.size * 2);
    const availH = (b.bottom - b.top) + inf.free;
    const baseRatio = Math.min(1.6, Math.max(1.05, b.leading / b.size));

    let chosen: { size: number; ratio: number; lines: string[] } | null = null;
    const minScale = 0.72;
    outer:
    for (let s = 1; s >= minScale - 1e-6; s -= 0.03) {
      const sizePx = b.size * s;
      for (const ratio of [baseRatio, Math.max(1.05, baseRatio * 0.92)]) {
        ctx.font = fontFor(b, sizePx);
        const lines = wrapWords(ctx, text, width);
        const h = (lines.length - 1) * sizePx * ratio + sizePx * 1.2;
        if (h <= availH + 0.5) {
          chosen = { size: sizePx, ratio, lines };
          if (s < 0.985) report.shrunkIds.push(b.id);
          break outer;
        }
      }
    }
    if (!chosen) {
      const sizePx = b.size * minScale;
      ctx.font = fontFor(b, sizePx);
      chosen = { size: sizePx, ratio: 1.05, lines: wrapWords(ctx, text, width) };
      report.overflowIds.push(b.id);
    }

    // Nếu bản dịch cần nhiều chỗ hơn vùng đã xoá, xoá thêm phần giãn (vùng này vốn là nền trống)
    const neededBottom = b.top + (chosen.lines.length - 1) * chosen.size * chosen.ratio + chosen.size * 1.25;
    if (neededBottom > b.bottom) {
      const padX = 0.15 * b.size;
      ctx.fillStyle = rgbCss(inf.bg);
      ctx.fillRect(b.x0 - padX, b.bottom, b.x1 - b.x0 + 2 * padX, neededBottom - b.bottom);
    }

    ctx.save();
    ctx.font = fontFor(b, chosen.size);
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = inf.fg ? rgbCss(inf.fg) : '#1a1a1a';
    let y = b.top + chosen.size * 0.93;
    chosen.lines.forEach((line, i) => {
      drawLine(ctx, line, x0, width, y, b.align, i === chosen!.lines.length - 1, chosen!.size);
      y += chosen!.size * chosen!.ratio;
    });
    ctx.restore();
    report.painted++;
  }

  return report;
}
