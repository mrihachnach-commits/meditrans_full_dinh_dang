import { GoogleGenerativeAI, SchemaType } from "@google/generative-ai";
import { TranslationService, TranslationOptions } from "./translationService";
import { cleanLatex } from "../utils/textFormatting";
import { auth } from "../firebase";

export class GeminiService implements TranslationService {
  private apiKeys: string[] = [];
  private modelName: string;
  private exhaustedKeys: Set<string> = new Set();
  private static globalKeyLastUsed: Map<string, number> = new Map();
  private static lastSuccessfulKey: string | null = null;
  private static requestDispatchLock: Promise<void> = Promise.resolve();

  constructor(apiKeys?: string | string[], modelName: string = "gemini-2.5-flash-lite") {
    const cleanModel = (modelName || '').trim();
    if (!cleanModel || cleanModel === 'gemini' || cleanModel === 'shopaikey' || cleanModel === 'openai') {
      this.modelName = "gemini-2.5-flash-lite";
    } else {
      this.modelName = cleanModel;
    }
    
    if (Array.isArray(apiKeys)) {
      this.apiKeys = Array.from(new Set(apiKeys.filter(k => k && k.trim() !== "")));
    } else if (apiKeys && apiKeys.trim() !== "") {
      this.apiKeys = Array.from(new Set(apiKeys.split(/[,\n]/).map(k => k.trim()).filter(k => k !== "")));
    }
    
    this.apiKeys.forEach(k => {
      if (!GeminiService.globalKeyLastUsed.has(k)) {
        GeminiService.globalKeyLastUsed.set(k, 0);
      }
    });
    
    console.log(`[MediTrans] GeminiService: ${this.apiKeys.length} keys loaded. Model: ${this.modelName}`);
  }

  public static isProxyKey(key: string, engineOrModel?: string): boolean {
    if (!key) return false;
    const clean = key.trim();
    if (clean === 'system_proxy') return true;
    const eng = (engineOrModel || '').toLowerCase();
    if (clean.startsWith('sk-') || clean.startsWith('sh-') || clean.startsWith('sai-')) return true;
    if (eng === 'shopaikey' || eng.includes('openai') || eng.includes('proxy')) return true;
    if (!clean.startsWith('AIzaSy') && clean.length >= 16 && (eng === 'shopaikey' || eng.includes('proxy'))) return true;
    return false;
  }

  private isCurrentKeyProxy(key: string): boolean {
    return GeminiService.isProxyKey(key, this.modelName);
  }

  private getMIN_REQUEST_INTERVAL(key: string): number {
    if (this.isCurrentKeyProxy(key)) {
      // Stagger spacing for proxy multithreading
      return this.apiKeys.length > 1 ? 100 : 200;
    }
    return this.apiKeys.length > 5 ? 400 : 700;
  }

  private getBestAvailableKey(): string | null {
    if (this.apiKeys.length === 0) return null;

    const now = Date.now();
    const validKeys = this.apiKeys.filter(k => !this.exhaustedKeys.has(k));
    
    // If all keys are marked exhausted, use any key to avoid starving
    const candidateKeys = validKeys.length > 0 ? validKeys : this.apiKeys;

    if (GeminiService.lastSuccessfulKey && candidateKeys.includes(GeminiService.lastSuccessfulKey)) {
      const lastUsed = GeminiService.globalKeyLastUsed.get(GeminiService.lastSuccessfulKey) || 0;
      if (now - lastUsed >= this.getMIN_REQUEST_INTERVAL(GeminiService.lastSuccessfulKey)) {
        return GeminiService.lastSuccessfulKey;
      }
    }

    candidateKeys.sort((a, b) => (GeminiService.globalKeyLastUsed.get(a) || 0) - (GeminiService.globalKeyLastUsed.get(b) || 0));

    return candidateKeys[0];
  }

  private async acquireKeyAndInstance(): Promise<{ ai: any, key: string }> {
    const key = this.getBestAvailableKey();
    if (!key) {
      console.error("[MediTrans] No available API keys for GeminiService.");
      throw new Error("Không có API Key khả dụng (Tất cả đang bảo trì hoặc hết hạn mức).");
    }

    await this.waitForKeyRateLimit(key);
    
    try {
      const isProxy = this.isCurrentKeyProxy(key);
      console.log(`[MediTrans] Using key: ...${key.substring(key.length - 4)} (${isProxy ? 'ShopAIKey/Proxy' : 'Google Gemini'}) for ${this.modelName}`);
      if (isProxy) {
        return { ai: null, key };
      }
      const ai = new GoogleGenerativeAI(key);
      return { ai, key };
    } catch (e) {
      console.error("[MediTrans] Failed to initialize GoogleGenAI with key:", key.substring(key.length - 4), e);
      throw e;
    }
  }

  private async waitForKeyRateLimit(key: string): Promise<void> {
    const now = Date.now();
    const lastUsed = GeminiService.globalKeyLastUsed.get(key) || 0;
    const interval = this.getMIN_REQUEST_INTERVAL(key);
    
    if (now - lastUsed < interval) {
      const waitTime = interval - (now - lastUsed);
      if (waitTime > 30) {
        await new Promise(resolve => setTimeout(resolve, waitTime));
      }
    }
    
    GeminiService.globalKeyLastUsed.set(key, Date.now());
  }

  private rotateKey(exhaustedKey: string, isQuotaError: boolean = true): boolean {
    if (this.apiKeys.length <= 1) {
      // Single Key mode: Never permanently ban the single key!
      // Return true so exponential backoff will retry with the single key without crashing multithreading.
      console.warn(`[MediTrans] Single key ${isQuotaError ? 'quota/rate-limit' : 'temporary error'}. Will retry with exponential backoff.`);
      return true;
    }

    if (exhaustedKey) {
      const waitTime = isQuotaError ? 20000 : 5000;
      console.warn(`[MediTrans] Key ...${exhaustedKey.slice(-4)} ${isQuotaError ? 'QUOTA EXHAUSTED' : 'ERROR'}. Cooldown: ${waitTime}ms`);
      this.exhaustedKeys.add(exhaustedKey);
      
      setTimeout(() => {
        this.exhaustedKeys.delete(exhaustedKey);
        console.log(`[MediTrans] Key ...${exhaustedKey.slice(-4)} recovered.`);
      }, waitTime);
    }
    
    return true;
  }

  private mapModelForOpenAI(modelName: string): string {
    const customNormal = typeof window !== 'undefined' ? localStorage.getItem('mediTrans_customOpenAIModelNormal') : null;
    const customDeep = typeof window !== 'undefined' ? localStorage.getItem('mediTrans_customOpenAIModelDeep') : null;
    const legacyCustom = typeof window !== 'undefined' ? localStorage.getItem('mediTrans_customOpenAIModel') : null;

    const isDeepMode = modelName === 'gemini-3.6-flash' || modelName === 'gemini-3-flash-preview' || modelName.toLowerCase().includes('deep') || modelName.toLowerCase().includes('pro');

    if (isDeepMode) {
      if (customDeep && customDeep.trim()) {
        return customDeep.trim();
      }
      if (customNormal && customNormal.trim()) {
        return customNormal.trim();
      }
    } else {
      if (customNormal && customNormal.trim()) {
        return customNormal.trim();
      }
    }

    if (legacyCustom && legacyCustom.trim()) {
      return legacyCustom.trim();
    }

    if (modelName === 'gemini-flash-lite-latest' || modelName === 'gemini-flash' || modelName === 'gemini-2.5-flash-lite') {
      return 'gemini-2.5-flash-lite';
    }
    if (modelName === 'gemini-3.6-flash' || modelName === 'gemini-3-flash-preview') {
      return 'gemini-2.5-flash-lite';
    }
    return modelName;
  }

  public mapModelForGoogle(modelName?: string): string {
    const clean = (modelName || '').toLowerCase().trim();
    if (!clean || clean === 'gemini' || clean === 'shopaikey' || clean === 'openai') {
      return 'gemini-3.6-flash';
    }
    // If it is already an active modern Google Generative AI model name
    if (clean === 'gemini-3.6-flash' || clean === 'gemini-3-flash-preview' || clean === 'gemini-flash-latest') {
      return clean;
    }
    // Deep / Pro modes
    if (clean.includes('3.6') || clean.includes('pro') || clean.includes('deep')) {
      return 'gemini-3.6-flash';
    }
    // Default to active modern flash model
    return 'gemini-3.6-flash';
  }

  private getProxyBaseUrl(): string {
    const baseUrl = (typeof window !== 'undefined' ? localStorage.getItem('mediTrans_customBaseUrl') : null) || 'https://api.shopaikey.com/v1';
    let cleanBaseUrl = baseUrl.trim().replace(/\/+$/, '');
    if (!cleanBaseUrl.endsWith('/chat/completions')) {
      cleanBaseUrl = `${cleanBaseUrl}/chat/completions`;
    }
    return cleanBaseUrl;
  }

  private async *callOpenAIStream(
    key: string,
    model: string,
    systemInstruction: string,
    prompt: string,
    imageBase64: string,
    signal?: AbortSignal
  ): AsyncGenerator<string> {
    const cleanBaseUrl = this.getProxyBaseUrl();
    const mappedModel = this.mapModelForOpenAI(model);

    const messages: any[] = [];
    if (systemInstruction) {
      messages.push({ role: "system", content: systemInstruction });
    }

    const userContent: any[] = [];
    if (imageBase64) {
      const formattedImage = imageBase64.startsWith('data:') ? imageBase64 : `data:image/jpeg;base64,${imageBase64.split(',')[1] || imageBase64}`;
      userContent.push({
        type: "image_url",
        image_url: { 
          url: formattedImage,
          detail: "high"
        }
      });
    }
    userContent.push({ type: "text", text: prompt });

    messages.push({ role: "user", content: userContent });

    const body: any = {
      model: mappedModel,
      temperature: 0,
      max_tokens: 8192,
      stream: true,
      messages
    };

    let requestUrl = cleanBaseUrl;
    let authHeaderValue = `Bearer ${key.trim()}`;

    if (key.trim() === 'system_proxy') {
      requestUrl = '/api/ai/chat';
      const currentUser = auth.currentUser;
      if (!currentUser) {
        throw new Error("Vui lòng đăng nhập để sử dụng Key hệ thống.");
      }
      const token = await currentUser.getIdToken();
      authHeaderValue = `Bearer ${token}`;
    }

    console.log(`[MediTrans] Calling Stream (${requestUrl}) using model: ${mappedModel}`);

    const response = await fetch(requestUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": authHeaderValue
      },
      body: JSON.stringify(body),
      signal
    });

    if (!response.ok) {
      if (response.status === 403 && key.trim() === 'system_proxy') {
        throw new Error("Tài khoản của bạn chưa đủ Level 2 hoặc đã hết hạn.");
      }
      const errText = await response.text();
      throw new Error(`ShopAIKey/Proxy Error (${response.status}): ${errText}`);
    }

    if (!response.body) {
      throw new Error("Response body is empty");
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    let yieldedAny = false;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith(":")) continue;
        if (trimmed === "data: [DONE]" || trimmed === "data:[DONE]") {
          return;
        }
        if (trimmed.startsWith("data:")) {
          const jsonStr = trimmed.slice(5).trim();
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content || parsed.choices?.[0]?.message?.content;
            if (content) {
              yieldedAny = true;
              yield content;
            }
          } catch (e) {
            // silent parse ignore
          }
        }
      }
    }

    if (buffer.trim().startsWith("data:")) {
      const jsonStr = buffer.trim().slice(5).trim();
      if (jsonStr && jsonStr !== "[DONE]") {
        try {
          const parsed = JSON.parse(jsonStr);
          const content = parsed.choices?.[0]?.delta?.content || parsed.choices?.[0]?.message?.content;
          if (content) yield content;
        } catch (e) {}
      }
    }
  }

  private async callOpenAINonStream(
    key: string,
    model: string,
    systemInstruction: string,
    prompt: string,
    imageBase64: string,
    signal?: AbortSignal
  ): Promise<string> {
    const cleanBaseUrl = this.getProxyBaseUrl();
    const mappedModel = this.mapModelForOpenAI(model);

    const messages: any[] = [];
    if (systemInstruction) {
      messages.push({ role: "system", content: systemInstruction });
    }

    const userContent: any[] = [];
    if (imageBase64) {
      const formattedImage = imageBase64.startsWith('data:') ? imageBase64 : `data:image/jpeg;base64,${imageBase64.split(',')[1] || imageBase64}`;
      userContent.push({
        type: "image_url",
        image_url: { 
          url: formattedImage,
          detail: "high"
        }
      });
    }
    userContent.push({ type: "text", text: prompt });

    messages.push({ role: "user", content: userContent });

    const body: any = {
      model: mappedModel,
      temperature: 0,
      max_tokens: 8192,
      stream: false,
      messages
    };

    let requestUrl = cleanBaseUrl;
    let authHeaderValue = `Bearer ${key.trim()}`;

    if (key.trim() === 'system_proxy') {
      requestUrl = '/api/ai/chat';
      const currentUser = auth.currentUser;
      if (!currentUser) {
        throw new Error("Vui lòng đăng nhập để sử dụng Key hệ thống.");
      }
      const token = await currentUser.getIdToken();
      authHeaderValue = `Bearer ${token}`;
    }

    console.log(`[MediTrans] Calling Non-Stream (${requestUrl}) using model: ${mappedModel}`);

    const response = await fetch(requestUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": authHeaderValue
      },
      body: JSON.stringify(body),
      signal
    });

    if (!response.ok) {
      if (response.status === 403 && key.trim() === 'system_proxy') {
        throw new Error("Tài khoản của bạn chưa đủ Level 2 hoặc đã hết hạn.");
      }
      const errText = await response.text();
      throw new Error(`ShopAIKey/Proxy Error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content || "";
  }

  public async testSingleKeyTranslation(key: string, sampleText: string = "Hello world! Testing translation AI."): Promise<{ success: boolean; resultText?: string; error?: string; latencyMs?: number }> {
    if (!key || !key.trim()) return { success: false, error: "API Key trống" };
    const cleanKey = key.trim();
    if (cleanKey === 'system_proxy' || cleanKey.startsWith('system_')) {
      return { success: true, resultText: "Key hệ thống sẵn sàng", latencyMs: 0 };
    }
    const startTime = Date.now();
    const prompt = `Dịch câu sau sang tiếng Việt ngắn gọn: "${sampleText}"`;
    const systemInstruction = "Bạn là dịch giả y khoa. Dịch chính xác và ngắn gọn.";

    try {
      if (this.isCurrentKeyProxy(cleanKey)) {
        const text = await this.callOpenAINonStream(cleanKey, this.modelName, systemInstruction, prompt, "", undefined);
        const latencyMs = Date.now() - startTime;
        return { success: true, resultText: text || "Thành công", latencyMs };
      } else {
        const ai = new GoogleGenerativeAI(cleanKey);
        const candidates = Array.from(new Set([
          this.mapModelForGoogle(this.modelName),
          'gemini-3.6-flash',
          'gemini-3-flash-preview',
          'gemini-flash-latest'
        ]));
        
        let lastError: any = null;
        for (const modelCandidate of candidates) {
          try {
            const genModel = ai.getGenerativeModel({ model: modelCandidate });
            const res = await genModel.generateContent(`${systemInstruction}\n${prompt}`);
            const response = await res.response;
            const text = response.text()?.trim();
            const latencyMs = Date.now() - startTime;
            return { success: true, resultText: text || "Thành công", latencyMs };
          } catch (modelErr: any) {
            lastError = modelErr;
            if (modelErr?.message?.includes('404') || modelErr?.message?.toLowerCase().includes('not found')) {
              console.warn(`[GeminiService] Model ${modelCandidate} not available for key ...${cleanKey.slice(-4)}, trying next candidate...`);
              continue;
            }
            throw modelErr;
          }
        }
        throw lastError || new Error("Không thể kết nối với mô hình Gemini khả dụng.");
      }
    } catch (err: any) {
      return { success: false, error: err.message || "Lỗi không xác định" };
    }
  }

  public async testSingleKey(key: string): Promise<boolean> {
    if (!key || !key.trim()) return false;
    const cleanKey = key.trim();
    if (cleanKey === 'system_proxy' || cleanKey.startsWith('system_')) {
      return true;
    }
    if (this.isCurrentKeyProxy(cleanKey)) {
      try {
        const cleanBaseUrl = this.getProxyBaseUrl();
        const response = await fetch(cleanBaseUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${cleanKey}`
          },
          body: JSON.stringify({
            model: this.mapModelForOpenAI(this.modelName),
            messages: [{ role: 'user', content: 'hi' }],
            max_tokens: 5
          })
        });
        return response.ok;
      } catch (e) {
        return false;
      }
    } else {
      try {
        const ai = new GoogleGenerativeAI(cleanKey);
        const candidates = Array.from(new Set([
          this.mapModelForGoogle(this.modelName),
          'gemini-3.6-flash',
          'gemini-3-flash-preview'
        ]));
        for (const modelCandidate of candidates) {
          try {
            const genModel = ai.getGenerativeModel({ model: modelCandidate });
            const res = await genModel.generateContent('Hi');
            if (res) return true;
          } catch (e: any) {
            if (e?.message?.includes('404') || e?.message?.toLowerCase().includes('not found')) {
              continue;
            }
            return false;
          }
        }
        return false;
      } catch (e: any) {
        console.warn(`[GeminiService] testSingleKey error for ...${cleanKey.slice(-4)}:`, e?.message || e);
        return false;
      }
    }
  }

  public getStatusInfo() {
    const total = this.apiKeys.length;
    const active = this.apiKeys.filter(k => !this.exhaustedKeys.has(k)).length;
    return {
      model: this.modelName,
      totalKeys: total,
      activeKeys: active,
      lastUsedSuffix: GeminiService.lastSuccessfulKey ? GeminiService.lastSuccessfulKey.slice(-4) : '...'
    };
  }

  async hasApiKey(): Promise<boolean> {
    return this.getBestAvailableKey() !== null;
  }

  async checkAvailableKeys(): Promise<{ manualKey: boolean }> {
    const manualKey = this.apiKeys[0];
    if (!manualKey) return { manualKey: false };
    const isActive = await this.testSingleKey(manualKey);
    return { manualKey: isActive };
  }

  async openKeySelection(): Promise<void> {
    if (typeof window !== 'undefined' && (window as any).aistudio?.openSelectKey) {
      await (window as any).aistudio.openSelectKey();
    }
  }

  async *translateMedicalPageStream(options: TranslationOptions): AsyncGenerator<string> {
    const { imageBuffer, pageNumber, signal, model } = options;
    const requestModel = model || this.modelName;
    
    console.log(`[MediTrans] Starting stream translation for page: ${pageNumber} using model: ${requestModel}`);
    const totalStartTime = Date.now();

    if (signal?.aborted) {
      throw new Error("Translation aborted");
    }

    const systemInstruction = `BẠN LÀ CHUYÊN GIA DỊCH THUẬT Y KHOA CAO CẤP (ANH - VIỆT). 
QUY TẮC SỐ 1: BẢN KẾT QUẢ TRẢ VỀ PHẢI HOÀN TOÀN BẰNG TIẾNG VIỆT 100%. TUYỆT ĐỐI KHÔNG GIỮ NGUYÊN BẤT KỲ CÂU, ĐOẠN VĂN HAY TIÊU ĐỀ NÀO BẰNG TIẾNG ANH GỐC.

QUY TẮC BẮT BUỘC KHÔNG ĐƯỢC BỎ BẤT KỲ CHÚ THÍCH HÌNH ÁNH NÀO (CRITICAL - FIGURE CAPTIONS & IMAGE LABELS):
1. QUÉT KỸ 100% BỀ MẶT TRANG, ĐẶC BIỆT LÀ CÁC DÒNG CHỮ CHÚ THÍCH DƯỚI HOẶC BÊN CẠNH CÁC HÌNH ẢNH (Figure 1, Figure 2, Figure 3, A, B, v.v.):
   - DỊCH CHÚ THÍCH HÌNH: Dịch "Figure 1 – ..." -> "**Hình 1 – ...**", "Figure 2 – ..." -> "**Hình 2 – ...**"
   - DỊCH TẤT CẢ TỪ VIẾT TẮT VÀ THUẬT NGỮ TRONG HÌNH: (A), (B), "Pathology:..." -> "**Bệnh học:...**", DM, DBT, Simple cyst, carcinoma, DCIS, arrows, obscured, circumscribed, equal density mass...
   - BẮT BUỘC CHÈN ĐOẠN DỊCH CHÚ THÍCH HÌNH VÀO ĐÚNG VỊ TRÍ DƯỚI MỖI BỨC ẢNH. TUYỆT ĐỐI KHÔNG BỎ QUA BẤT KỲ CHÚ THÍCH HÌNH NÀO.

2. QUY TẮC BẮT BUỘC VỀ TOÁN HỌC & SO SÁNH (TUYỆT ĐỐI KHÔNG DÙNG MÃ LATEX THÔ):
   - TUYỆT ĐỐI KHÔNG dùng mã LaTeX thô như $> 50%$, $< 95%$, ($> 0%$ đến $\\le 2%$), \\pm, \\times, \\ge, \\le, \\approx, \\neq, \\mu\\text{m}.
   - BẮT BUỘC viết trực tiếp bằng văn bản thông thường và ký tự Unicode chuẩn: dùng '>', '<', '≤', '≥', '±', '×', '≈', '%', 'µm', '°C'.
   - Ví dụ đúng: '> 50% đến < 95%', '(> 0% đến ≤ 2%)', 'kích thước ≤ 2 cm', '± 5%', 'p < 0.05'.
   - Tuyệt đối không để sót các ký tự '$' hay các lệnh gạch chéo ngược '\\' của LaTeX.

3. QUY TẮC CẤU TRÚC PHÂN CẤP & GẠCH ĐẦU DÒNG (NESTED LISTS & BULLET HIERARCHY):
   - GIỮ NGUYÊN 100% CẤU TRÚC PHÂN CẤP TỪ TÀI LIỆU GỐC:
     Khi tài liệu gốc có các mục lớn, mục con lồng nhau (như Thể và biến chứng -> Tên tổn thương -> Chi tiết / Phương tiện Siêu âm, CT, MRI...): BẮT BUỘC dùng cú pháp Markdown thụt lề chuẩn (dùng đúng 2 hoặc 4 dấu cách thụt lề cho mỗi cấp lồng nhau):
       * Cấp 1 (Mục chính): - **Các thể và biến chứng**:
       * Cấp 2 (Tổn thương cụ thể):   - **Ổ dịch quanh tụy cấp tính**: dưới 4 tuần.
       * Cấp 3 (Đặc điểm):     - Ổ dịch không có vỏ bao.
       * Cấp 3 (Siêu âm):     - **Siêu âm**: Tổn thương giảm âm...
       * Cấp 3 (CT):     - **CT**: Ổ dịch giảm tỷ trọng đồng nhất...
       * Cấp 3 (MRI):     - **MRI**: Tổn thương giảm tín hiệu trên T1...
       * Cấp 2 (Tổn thương tiếp theo):   - **Nang giả tụy**: trên 4 tuần.
       * Cấp 3 (Đặc điểm):     - Ổ dịch có vỏ bao.
       * Cấp 3 (Siêu âm):     - **Siêu âm**: Khối trống âm đơn thùy...
       * Cấp 3 (CT):     - **CT**: Tổn thương giảm tỷ trọng đồng nhất...
   - TUYỆT ĐỐI KHÔNG ép tất cả các mục thành một danh sách phẳng cùng một cấp (Flat list toàn bộ chấm tròn).
   - TUYỆT ĐỐI KHÔNG gộp các tiêu đề mục khác cấp vào cùng một dòng.
   - Tên phương tiện (Siêu âm, CT, MRI, X-quang) BẮT BUỘC in đậm: **Siêu âm**:, **CT**:, **MRI**:.

4. TRÌNH BÀY ĐẸP VÀ PHÂN CHIA RÕ RÀNG BẰNG MARKDOWN:
   - Dùng tiêu đề Markdown (#, ##, ###, ####) cho tiêu đề trang, tên chương, tiêu đề mục lớn/nhỏ (Ví dụ: ### GIỚI THIỆU, ### PHẦN I: ..., ### A. KHỐI U...).
   - ĐỊNH DẠNG PHÂN CẤP RÕ RÀNG: Các số thứ tự mục (1., 2., 3...) và các chữ cái phân cấp (a., b., c., d...) BẮT BUỘC phải nằm trên DÒNG RIÊNG BIỆT, in đậm (VD: **1. HÌNH DẠNG**, **d. Không đều**), cách nhau bằng xuống dòng kép (\\n\\n). TUYỆT ĐỐI KHÔNG gộp chung dính liền dòng.
   - BẮT BUỘC phân chia các đoạn văn, tiêu đề và các item bằng dấu xuống dòng kép (\\n\\n) rõ ràng.

5. DỊCH ĐẦY ĐỦ 100% CÁC CỘT VÀ Ô TRONG BẢNG BIỂU (CRITICAL - TABLES):
   - GIỮ NGUYÊN ĐÚNG SỐ LƯỢNG CỘT CỦA BẢNG GỐC TRONG ẢNH.
   - BẮT BUỘC dùng cú pháp Markdown chuẩn cho bảng:
     * Dòng đầu là tiêu đề hoặc nội dung hàng 1: | Cột 1 | Cột 2 | Cột 3 | ... |
     * Dòng thứ hai là phân cách: |---|---|---|...| (BẮT BUỘC có gạch đứng '|' ở cả đầu và cuối dòng, có đủ số cột tương ứng).
     * Các dòng tiếp theo là dữ liệu: | Ô 1 | Ô 2 | Ô 3 | ... |
     * TUYỆT ĐỐI KHÔNG viết thiếu gạch đứng '|' ở đầu hoặc cuối dòng. TUYỆT ĐỐI KHÔNG viết dạng '--|---|---' thiếu gạch đứng '|'.
     * BẮT BUỘC mỗi hàng của bảng phải nằm trên MỘT DÒNG RIÊNG BIỆT (xuống dòng \\n sau mỗi hàng). TUYỆT ĐỐI KHÔNG dính liền các hàng bảng vào cùng một dòng.
     * BẮT BUỘC có một dòng trống (\\n\\n) trước và sau mỗi bảng để Markdown hiển thị bảng chuẩn đẹp.
   - Dịch toàn bộ tiêu đề cột, tiêu đề hàng và từng ô nhỏ trong bảng sang tiếng Việt 100%.

6. KHÔNG LỜI DẪN / KHÔNG CHÚ THÍCH THÊM: Dịch trực tiếp nội dung từ dòng đầu tiên cho tới dòng cuối cùng ở cuối trang.

7. XỬ LÝ BỐ CỤC ĐA CỘT & KHỐI TỪ VIẾT TẮT (TWO-COLUMN & ABBREVIATIONS):
   - KHỐI TỪ VIẾT TẮT (ABBREVIATIONS): Khi trang có khung hoặc danh sách các từ viết tắt độc lập (như RV, SA, SCCT, SMT, VSD...): BẮT BUỘC trình bày riêng biệt thành danh sách viết tắt (VD: - **RV**: Tâm thất phải (Right ventricle)...) hoặc Bảng từ viết tắt riêng. TUYỆT ĐỐI KHÔNG đọc ngang hàng ghép các từ viết tắt của cột này với câu văn của cột bên cạnh thành một bảng hỗn tạp!
   - THỨ TỰ ĐỌC 2 CỘT: Đọc theo luồng logic tự nhiên của bài viết y khoa: Đọc trọn vẹn khối văn bản tiếp nối từ trang trước hoặc cột trái trước khi chuyển sang các phần mục mới (như 10.1 Giới thiệu, 10.2 Giải phẫu động mạch vành). TUYỆT ĐỐI KHÔNG đọc ngang hàng cắt ngang giữa 2 cột khác nhau.`;

    const prompt = `[YÊU CẦU BẮT BUỘC TỐI THƯỢNG: BẢN KẾT QUẢ TRẢ VỀ PHẢI HOÀN TOÀN BẰNG TIẾNG VIỆT 100%. BẮT BUỘC DỊCH TẤT CẢ CHÚ THÍCH HÌNH ÁNH DƯỚI HÌNH (FIGURE 1, FIGURE 2, FIGURE A, B, PATHOLOGY...). KHÔNG ĐƯỢC BỎ BẤT KỲ CHÚ THÍCH HÌNH NÀO].

YÊU CẦU DỊCH THUẬT VÀ TRÌNH BÀY MARKDOWN ĐẸP 100% SANG TIẾNG VIỆT (Trang ${pageNumber}):
- Dịch hoàn toàn toàn bộ văn bản, đoạn văn sang tiếng Việt.
- TUYỆT ĐỐI KHÔNG DÙNG MÃ LATEX THÔ: Viết trực tiếp ký hiệu toán học / so sánh thông thường (>, <, ≤, ≥, ±, %, µm, °C), ví dụ: '> 50% đến < 95%', '(> 0% đến ≤ 2%)'. Tuyệt đối không dùng dấu $ hay mã LaTeX thô như $\\le$, $\\ge$, $\\pm$.
- BẢO TỒN CẤU TRÚC PHÂN CẤP GẠCH ĐẦU DÒNG (NESTED LISTS): Dùng đúng 2 hoặc 4 dấu cách thụt lề cho các mục con, nhóm tổn thương và phương tiện chẩn đoán (Siêu âm, CT, MRI). Tuyệt đối không làm phẳng danh sách thành một cấp duy nhất.
- BẢNG BIỂU MARKDOWN CHUẨN: Bắt buộc mọi hàng bảng phải có gạch đứng '|' ở đầu và cuối dòng (| Cột 1 | Cột 2 |), dòng phân cách phải là '|---|---|', mỗi hàng nằm trên một dòng riêng biệt, có dòng trống trước và sau bảng.
- KHỐI TỪ VIẾT TẮT: Trình bày riêng danh sách từ viết tắt (RV, SA, SCCT...), tuyệt đối không ghép ngang từ viết tắt với câu văn cột bên cạnh.
- NHẬN DIỆN BỐ CỤC 2 CỘT (TWO-COLUMN): Đọc và dịch tuần tự, liên mạch giữa các cột văn bản, giữ nguyên sự kết nối chặt chẽ của nội dung y khoa, không để bị ngắt quãng hoặc đẩy lệch đoạn dịch xuống dưới.
- DỊCH CHI TIẾT TẤT CẢ CÁC CHÚ THÍCH HÌNH (FIGURE CAPTIONS):
  + "Figure 1 – ..." -> "**Hình 1 – ...**"
  + "Figure 2 – ..." -> "**Hình 2 – ...**"
  + Dịch đầy đủ nội dung mô tả hình (A, B, DM, DBT, Pathology, v.v.).
- YÊU CẦU ĐỊNH DẠNG MARKDOWN CỰC KỲ NGUYÊN TẮC:
  + Dùng tiêu đề Markdown (###) cho các tiêu đề chính/phần.
  + Các mục đánh số (1., 2., 3...) và chữ cái (a., b., c., d...) PHẢI nằm trên dòng riêng, in đậm rõ ràng, phân tách bằng xuống dòng kép (\\n\\n).
  + BẮT BUỘC xuất tất cả các bảng biểu dưới dạng Bảng Markdown có ĐỦ SỐ CỘT NHƯ BẢNG GỐC (| Cột 1 | Cột 2 | Cột 3 | ... |).
  + Phân tách rõ ràng giữa các đoạn văn và mục bằng xuống dòng kép (\\n\\n).`;

    const MAX_RETRIES = 6;
    let retryCount = 0;

    while (retryCount <= MAX_RETRIES) {
      if (signal?.aborted) {
        throw new Error("Translation aborted");
      }
      
      let ai, key: string;
      try {
        ({ ai, key } = await this.acquireKeyAndInstance());
      } catch (e: any) {
        throw new Error("Không tìm thấy API Key khả dụng. Vui lòng kiểm tra lại Key trong Cài đặt.");
      }

      const isProxy = this.isCurrentKeyProxy(key);

      // Handle ShopAIKey / OpenAI Proxy Key
      if (isProxy) {
        try {
          let fullText = "";
          for await (const chunkText of this.callOpenAIStream(key, requestModel, systemInstruction, prompt, imageBuffer, signal)) {
            if (signal?.aborted) break;
            fullText += chunkText;
            yield chunkText;
          }
          GeminiService.lastSuccessfulKey = key;
          
          if (!fullText) {
            // Auto fallback to non-stream if stream ended with 0 text
            console.warn(`[MediTrans] Stream returned empty for page ${pageNumber}. Retrying non-stream...`);
            const fallbackText = await this.callOpenAINonStream(key, requestModel, systemInstruction, prompt, imageBuffer, signal);
            if (fallbackText) {
              fullText = fallbackText;
              yield fallbackText;
            } else {
              throw new Error("Proxy API returned empty response.");
            }
          }
          
          console.log(`[MediTrans] Translation for page: ${pageNumber} finished via ShopAIKey/Proxy in ${((Date.now() - totalStartTime) / 1000).toFixed(2)}s`);
          return;
        } catch (error: any) {
          if (signal?.aborted || error.message === "Translation aborted") {
            throw new Error("Translation aborted");
          }
          const isQuota = error.message?.includes("429") || error.message?.toLowerCase().includes("quota") || error.message?.includes("401");
          const isServerErr = error.message?.includes("500") || error.message?.includes("502") || error.message?.includes("503") || error.message?.includes("504") || error.message?.toLowerCase().includes("fetch");
          
          if (retryCount < MAX_RETRIES && this.rotateKey(key, isQuota)) {
            retryCount++;
            const delay = Math.min(8000, Math.pow(1.5, retryCount) * 800 + Math.random() * 500);
            console.warn(`[MediTrans] Retrying page ${pageNumber} (attempt ${retryCount}/${MAX_RETRIES}) after ${delay.toFixed(0)}ms...`);
            await new Promise(resolve => setTimeout(resolve, delay));
            continue;
          }
          throw error;
        }
      }

      // Handle Standard Google Gemini Key (AIzaSy...)
      try {
        const fetchStartTime = Date.now();
        const googleModel = this.mapModelForGoogle(requestModel);
        const genModel = ai.getGenerativeModel({ 
          model: googleModel,
          systemInstruction: systemInstruction,
          generationConfig: {
            temperature: 0,
          }
        });

        const response = await genModel.generateContentStream([
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageBuffer.split(",")[1] || imageBuffer,
            },
          },
          prompt,
        ]);

        console.log(`[MediTrans] API request sent. Model: ${requestModel}. Wait time for stream start...`);
        let fullText = "";
        let chunkCount = 0;
        for await (const chunk of response.stream) {
          if (signal?.aborted) {
            console.log("[MediTrans] Stream aborted by signal");
            break; 
          }
          if (chunkCount === 0) {
            console.log(`[MediTrans] Stream started after ${Date.now() - fetchStartTime}ms`);
          }
          chunkCount++;
          
          let chunkText = "";
          try {
             chunkText = chunk.text();
          } catch (e) {
             console.warn("[MediTrans] Error reading chunk text", e);
             continue;
          }

          if (chunkText) {
            fullText += chunkText;
            yield chunkText;
          }
        }

        GeminiService.lastSuccessfulKey = key;
        if (!fullText) {
          throw new Error("Model returned no text.");
        }
        
        console.log(`[MediTrans] Translation for page: ${pageNumber} finished in ${((Date.now() - totalStartTime) / 1000).toFixed(2)}s`);
        break;

      } catch (error: any) {
        if (signal?.aborted || error.message === "Translation aborted") {
          throw new Error("Translation aborted");
        }
        const isQuotaError = error.message?.toLowerCase().includes("quota") || 
                           error.message?.toLowerCase().includes("429") ||
                           error.message?.toLowerCase().includes("resource_exhausted");
        const isUnavailableError = error.message?.toLowerCase().includes("unavailable") || 
                                 error.message?.toLowerCase().includes("503") ||
                                 error.message?.toLowerCase().includes("high demand");
        const isPermissionDeniedError = error.message?.toLowerCase().includes("permission_denied") || 
                                       error.message?.toLowerCase().includes("403") ||
                                       error.message?.toLowerCase().includes("denied access");
        const isNetworkError = error.message?.includes("status code: 0") || 
                              error.message?.includes("code: 0") ||
                              error.message?.toLowerCase().includes("fetch failed");
        
        if ((isQuotaError || isUnavailableError || isPermissionDeniedError || isNetworkError) && retryCount < MAX_RETRIES) {
          const canRotate = this.rotateKey(key, isQuotaError || isPermissionDeniedError);
          retryCount++;
          if (canRotate && this.apiKeys.length > 1) {
            await new Promise(resolve => setTimeout(resolve, 200 + Math.random() * 300));
            continue;
          }
          const delay = Math.pow(1.5, retryCount) * 1000 + Math.random() * 500;
          await new Promise(resolve => setTimeout(resolve, delay));
          continue;
        }
        throw error;
      }
    }
  }

  async translateMedicalPage(options: TranslationOptions): Promise<string> {
    const { imageBuffer, pageNumber, signal, model } = options;
    const requestModel = model || this.modelName;
    
    console.log(`[MediTrans] Starting non-stream translation for page: ${pageNumber} using model: ${requestModel}`);
    const totalStartTime = Date.now();
    
    if (signal?.aborted) throw new Error("Translation aborted");

    const MAX_RETRIES = 6;
    let retryCount = 0;

    while (retryCount <= MAX_RETRIES) {
      if (signal?.aborted) throw new Error("Translation aborted");
      let ai, key: string;
      try {
        ({ ai, key } = await this.acquireKeyAndInstance());
      } catch (e) {
        throw new Error("Không tìm thấy API Key khả dụng.");
      }

      const systemInstruction = `BẠN LÀ CHUYÊN GIA DỊCH THUẬT Y KHOA CAO CẤP (ANH - VIỆT). 
QUY TẮC SỐ 1: BẢN KẾT QUẢ TRẢ VỀ PHẢI HOÀN TOÀN BẰNG TIẾNG VIỆT 100%. TUYỆT ĐỐI KHÔNG GIỮ NGUYÊN BẤT KỲ CÂU, ĐOẠN VĂN HAY TIÊU ĐỀ NÀO BẰNG TIẾNG ANH GỐC.

QUY TẮC BẮT BUỘC KHÔNG ĐƯỢC BỎ BẤT KỲ CHÚ THÍCH HÌNH ÁNH NÀO (CRITICAL - FIGURE CAPTIONS & IMAGE LABELS):
1. QUÉT KỸ 100% BỀ MẶT TRANG, ĐẶC BIỆT LÀ CÁC DÒNG CHỮ CHÚ THÍCH DƯỚI HOẶC BÊN CẠNH CÁC HÌNH ẢNH (Figure 1, Figure 2, Figure 3, A, B, v.v.):
   - DỊCH CHÚ THÍCH HÌNH: Dịch "Figure 1 – ..." -> "**Hình 1 – ...**", "Figure 2 – ..." -> "**Hình 2 – ...**"
   - DỊCH TẤT CẢ TỪ VIẾT TẮT VÀ THUẬT NGỮ TRONG HÌNH: (A), (B), "Pathology:..." -> "**Bệnh học:...**", DM, DBT, Simple cyst, carcinoma, DCIS, arrows, obscured, circumscribed, equal density mass...
   - BẮT BUỘC CHÈN ĐOẠN DỊCH CHÚ THÍCH HÌNH VÀO ĐÚNG VỊ TRÍ DƯỚI MỖI BỨC ẢNH. TUYỆT ĐỐI KHÔNG BỎ QUA BẤT KỲ CHÚ THÍCH HÌNH NÀO.

2. QUY TẮC BẮT BUỘC VỀ TOÁN HỌC & SO SÁNH (TUYỆT ĐỐI KHÔNG DÙNG MÃ LATEX THÔ):
   - TUYỆT ĐỐI KHÔNG dùng mã LaTeX thô như $> 50%$, $< 95%$, ($> 0%$ đến $\\le 2%$), \\pm, \\times, \\ge, \\le, \\approx, \\neq, \\mu\\text{m}.
   - BẮT BUỘC viết trực tiếp bằng văn bản thông thường và ký tự Unicode chuẩn: dùng '>', '<', '≤', '≥', '±', '×', '≈', '%', 'µm', '°C'.
   - Ví dụ đúng: '> 50% đến < 95%', '(> 0% đến ≤ 2%)', 'kích thước ≤ 2 cm', '± 5%', 'p < 0.05'.
   - Tuyệt đối không để sót các ký tự '$' hay các lệnh gạch chéo ngược '\\' của LaTeX.

3. QUY TẮC CẤU TRÚC PHÂN CẤP & GẠCH ĐẦU DÒNG (NESTED LISTS & BULLET HIERARCHY):
   - GIỮ NGUYÊN 100% CẤU TRÚC PHÂN CẤP TỪ TÀI LIỆU GỐC:
     Khi tài liệu gốc có các mục lớn, mục con lồng nhau (như Thể và biến chứng -> Tên tổn thương -> Chi tiết / Phương tiện Siêu âm, CT, MRI...): BẮT BUỘC dùng cú pháp Markdown thụt lề chuẩn (dùng đúng 2 hoặc 4 dấu cách thụt lề cho mỗi cấp lồng nhau):
       * Cấp 1 (Mục chính): - **Các thể và biến chứng**:
       * Cấp 2 (Tổn thương cụ thể):   - **Ổ dịch quanh tụy cấp tính**: dưới 4 tuần.
       * Cấp 3 (Đặc điểm):     - Ổ dịch không có vỏ bao.
       * Cấp 3 (Siêu âm):     - **Siêu âm**: Tổn thương giảm âm...
       * Cấp 3 (CT):     - **CT**: Ổ dịch giảm tỷ trọng đồng nhất...
       * Cấp 3 (MRI):     - **MRI**: Tổn thương giảm tín hiệu trên T1...
       * Cấp 2 (Tổn thương tiếp theo):   - **Nang giả tụy**: trên 4 tuần.
       * Cấp 3 (Đặc điểm):     - Ổ dịch có vỏ bao.
       * Cấp 3 (Siêu âm):     - **Siêu âm**: Khối trống âm đơn thùy...
       * Cấp 3 (CT):     - **CT**: Tổn thương giảm tỷ trọng đồng nhất...
   - TUYỆT ĐỐI KHÔNG ép tất cả các mục thành một danh sách phẳng cùng một cấp (Flat list toàn bộ chấm tròn).
   - TUYỆT ĐỐI KHÔNG gộp các tiêu đề mục khác cấp vào cùng một dòng.
   - Tên phương tiện (Siêu âm, CT, MRI, X-quang) BẮT BUỘC in đậm: **Siêu âm**:, **CT**:, **MRI**:.

4. TRÌNH BÀY ĐẸP VÀ PHÂN CHIA RÕ RÀNG BẰNG MARKDOWN:
   - Dùng tiêu đề Markdown (#, ##, ###, ####) cho tiêu đề trang, tên chương, tiêu đề mục lớn/nhỏ (Ví dụ: ### GIỚI THIỆU, ### PHẦN I: ..., ### A. KHỐI U...).
   - ĐỊNH DẠNG PHÂN CẤP RÕ RÀNG: Các số thứ tự mục (1., 2., 3...) và các chữ cái phân cấp (a., b., c., d...) BẮT BUỘC phải nằm trên DÒNG RIÊNG BIỆT, in đậm (VD: **1. HÌNH DẠNG**, **d. Không đều**), cách nhau bằng xuống dòng kép (\\n\\n). TUYỆT ĐỐI KHÔNG gộp chung dính liền dòng.
   - BẮT BUỘC phân chia các đoạn văn, tiêu đề và các item bằng dấu xuống dòng kép (\\n\\n) rõ ràng.

5. DỊCH ĐẦY ĐỦ 100% CÁC CỘT VÀ Ô TRONG BẢNG BIỂU (CRITICAL - TABLES):
   - GIỮ NGUYÊN ĐÚNG SỐ LƯỢNG CỘT CỦA BẢNG GỐC TRONG ẢNH.
   - BẮT BUỘC dùng cú pháp Markdown chuẩn cho bảng:
     * Dòng đầu là tiêu đề hoặc nội dung hàng 1: | Cột 1 | Cột 2 | Cột 3 | ... |
     * Dòng thứ hai là phân cách: |---|---|---|...| (BẮT BUỘC có gạch đứng '|' ở cả đầu và cuối dòng, có đủ số cột tương ứng).
     * Các dòng tiếp theo là dữ liệu: | Ô 1 | Ô 2 | Ô 3 | ... |
     * TUYỆT ĐỐI KHÔNG viết thiếu gạch đứng '|' ở đầu hoặc cuối dòng. TUYỆT ĐỐI KHÔNG viết dạng '--|---|---' thiếu gạch đứng '|'.
     * BẮT BUỘC mỗi hàng của bảng phải nằm trên MỘT DÒNG RIÊNG BIỆT (xuống dòng \\n sau mỗi hàng). TUYỆT ĐỐI KHÔNG dính liền các hàng bảng vào cùng một dòng.
     * BẮT BUỘC có một dòng trống (\\n\\n) trước và sau mỗi bảng để Markdown hiển thị bảng chuẩn đẹp.
   - Dịch toàn bộ tiêu đề cột, tiêu đề hàng và từng ô nhỏ trong bảng sang tiếng Việt 100%.

6. KHÔNG LỜI DẪN / KHÔNG CHÚ THÍCH THÊM: Dịch trực tiếp nội dung từ dòng đầu tiên cho tới dòng cuối cùng ở cuối trang.

7. XỬ LÝ BỐ CỤC ĐA CỘT & KHỐI TỪ VIẾT TẮT (TWO-COLUMN & ABBREVIATIONS):
   - KHỐI TỪ VIẾT TẮT (ABBREVIATIONS): Khi trang có khung hoặc danh sách các từ viết tắt độc lập (như RV, SA, SCCT, SMT, VSD...): BẮT BUỘC trình bày riêng biệt thành danh sách viết tắt (VD: - **RV**: Tâm thất phải (Right ventricle)...) hoặc Bảng từ viết tắt riêng. TUYỆT ĐỐI KHÔNG đọc ngang hàng ghép các từ viết tắt của cột này với câu văn của cột bên cạnh thành một bảng hỗn tạp!
   - THỨ TỰ ĐỌC 2 CỘT: Đọc theo luồng logic tự nhiên của bài viết y khoa: Đọc trọn vẹn khối văn bản tiếp nối từ trang trước hoặc cột trái trước khi chuyển sang các phần mục mới (như 10.1 Giới thiệu, 10.2 Giải phẫu động mạch vành). TUYỆT ĐỐI KHÔNG đọc ngang hàng cắt ngang giữa 2 cột khác nhau.`;

      const prompt = `[YÊU CẦU BẮT BUỘC TỐI THƯỢNG: BẢN KẾT QUẢ TRẢ VỀ PHẢI HOÀN TOÀN BẰNG TIẾNG VIỆT 100%. BẮT BUỘC DỊCH TẤT CẢ CHÚ THÍCH HÌNH ÁNH DƯỚI HÌNH (FIGURE 1, FIGURE 2, FIGURE A, B, PATHOLOGY...). KHÔNG ĐƯỢC BỎ BẤT KỲ CHÚ THÍCH HÌNH NÀO].

YÊU CẦU DỊCH THUẬT VÀ TRÌNH BÀY MARKDOWN ĐẸP 100% SANG TIẾNG VIỆT (Trang ${pageNumber}):
- Dịch hoàn toàn toàn bộ văn bản, đoạn văn sang tiếng Việt.
- TUYỆT ĐỐI KHÔNG DÙNG MÃ LATEX THÔ: Viết trực tiếp ký hiệu toán học / so sánh thông thường (>, <, ≤, ≥, ±, %, µm, °C), ví dụ: '> 50% đến < 95%', '(> 0% đến ≤ 2%)'. Tuyệt đối không dùng dấu $ hay mã LaTeX thô như $\\le$, $\\ge$, $\\pm$.
- BẢO TỒN CẤU TRÚC PHÂN CẤP GẠCH ĐẦU DÒNG (NESTED LISTS): Dùng đúng 2 hoặc 4 dấu cách thụt lề cho các mục con, nhóm tổn thương và phương tiện chẩn đoán (Siêu âm, CT, MRI). Tuyệt đối không làm phẳng danh sách thành một cấp duy nhất.
- BẢNG BIỂU MARKDOWN CHUẨN: Bắt buộc mọi hàng bảng phải có gạch đứng '|' ở đầu và cuối dòng (| Cột 1 | Cột 2 |), dòng phân cách phải là '|---|---|', mỗi hàng nằm trên một dòng riêng biệt, có dòng trống trước và sau bảng.
- KHỐI TỪ VIẾT TẮT: Trình bày riêng danh sách từ viết tắt (RV, SA, SCCT...), tuyệt đối không ghép ngang từ viết tắt với câu văn cột bên cạnh.
- NHẬN DIỆN BỐ CỤC 2 CỘT (TWO-COLUMN): Đọc và dịch tuần tự, liên mạch giữa các cột văn bản, giữ nguyên sự kết nối chặt chẽ của nội dung y khoa, không để bị ngắt quãng hoặc đẩy lệch đoạn dịch xuống dưới.
- DỊCH CHI TIẾT TẤT CẢ CÁC CHÚ THÍCH HÌNH (FIGURE CAPTIONS):
  + "Figure 1 – ..." -> "**Hình 1 – ...**"
  + "Figure 2 – ..." -> "**Hình 2 – ...**"
  + Dịch đầy đủ nội dung mô tả hình (A, B, DM, DBT, Pathology, v.v.).
- YÊU CẦU ĐỊNH DẠNG MARKDOWN CỰC KỲ NGUYÊN TẮC:
  + Dùng tiêu đề Markdown (###) cho các tiêu đề chính/phần.
  + Các mục đánh số (1., 2., 3...) và chữ cái (a., b., c., d...) PHẢI nằm trên dòng riêng, in đậm rõ ràng, phân tách bằng xuống dòng kép (\\n\\n).
  + BẮT BUỘC xuất tất cả các bảng biểu dưới dạng Bảng Markdown có ĐỦ SỐ CỘT NHƯ BẢNG GỐC (| Cột 1 | Cột 2 | Cột 3 | ... |).
  + Phân tách rõ ràng giữa các đoạn văn và mục bằng xuống dòng kép (\\n\\n).`;

      const isProxy = this.isCurrentKeyProxy(key);

      if (isProxy) {
        try {
          const text = await this.callOpenAINonStream(key, requestModel, systemInstruction, prompt, imageBuffer, signal);
          const resultText = text.replace(/(\s*\.\s*){4,}/g, ' ... ');
          GeminiService.lastSuccessfulKey = key;
          return resultText;
        } catch (error: any) {
          if (signal?.aborted) throw new Error("Translation aborted");
          const isQuota = error.message?.includes("429") || error.message?.toLowerCase().includes("quota") || error.message?.includes("401");
          if (retryCount < MAX_RETRIES && this.rotateKey(key, isQuota)) {
            retryCount++;
            const delay = Math.min(8000, Math.pow(1.5, retryCount) * 800 + Math.random() * 500);
            await new Promise(resolve => setTimeout(resolve, delay));
            continue;
          }
          throw error;
        }
      }

      try {
        const googleModel = this.mapModelForGoogle(requestModel);
        const genModel = ai.getGenerativeModel({ 
          model: googleModel,
          systemInstruction: systemInstruction,
          generationConfig: { temperature: 0 }
        });

        const result = await genModel.generateContent([
          { inlineData: { mimeType: "image/jpeg", data: imageBuffer.split(",")[1] || imageBuffer } },
          prompt
        ]);

        const response = await result.response;
        let text = response.text() || "";
        const resultText = text.replace(/(\s*\.\s*){4,}/g, ' ... ');
        console.log(`[MediTrans] Translation for page: ${pageNumber} finished in ${((Date.now() - totalStartTime) / 1000).toFixed(2)}s`);
        return resultText;
      } catch (error: any) {
        if (signal?.aborted) throw new Error("Translation aborted");
        
        const isPermissionDeniedError = error.message?.toLowerCase().includes("permission_denied") || 
                                       error.message?.toLowerCase().includes("403") ||
                                       error.message?.toLowerCase().includes("denied access");
        const isQuotaError = error.message?.toLowerCase().includes("quota") || 
                           error.message?.toLowerCase().includes("429") ||
                           error.message?.toLowerCase().includes("resource_exhausted");
        const isNetworkError = error.message?.includes("status code: 0") || 
                              error.message?.includes("code: 0") ||
                              error.message?.toLowerCase().includes("fetch failed");

        if (retryCount < MAX_RETRIES && this.rotateKey(key, isQuotaError || isPermissionDeniedError || isNetworkError)) {
          retryCount++;
          const delay = Math.pow(1.5, retryCount) * 1000 + Math.random() * 500;
          await new Promise(resolve => setTimeout(resolve, delay));
          continue;
        }
        throw error;
      }
    }
    return "Lỗi: Quá số lần thử lại.";
  }

  async lookupMedicalTerm(term: string): Promise<any> {
    const systemInstruction = `Chuyên gia từ điển y khoa. Trả về JSON.`;
    const prompt = `Tra cứu: "${term}"`;

    let ai, key: string;
    try {
      ({ ai, key } = await this.acquireKeyAndInstance());
    } catch (e) {
      throw new Error("Không tìm thấy API Key.");
    }

    if (this.isCurrentKeyProxy(key)) {
      const text = await this.callOpenAINonStream(key, this.modelName, systemInstruction, prompt, "", undefined);
      return JSON.parse(text.replace(/```json\n?|```/g, '').trim());
    }

    try {
      const googleModel = this.mapModelForGoogle(this.modelName);
      const genModel = ai.getGenerativeModel({ 
        model: googleModel,
        systemInstruction: systemInstruction,
        generationConfig: {
          temperature: 0,
          responseMimeType: "application/json",
          responseSchema: {
            type: SchemaType.OBJECT,
            properties: {
              term: { type: SchemaType.STRING },
              definition: { type: SchemaType.STRING },
              synonyms: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } },
              relatedTerms: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } },
              source: { type: SchemaType.STRING }
            },
            required: ["term", "definition"]
          }
        }
      });

      const result = await genModel.generateContent(prompt);
      const response = await result.response;
      return JSON.parse(response.text().replace(/```json\n?|```/g, '').trim());
    } catch (error: any) {
      throw error;
    }
  }

  async performOCR(imageBuffer: string): Promise<string> {
    let ai, key: string;
    try {
       ({ ai, key } = await this.acquireKeyAndInstance());
    } catch (e) {
       throw new Error("Không có API Key khả dụng.");
    }

    const systemInstruction = `OCR Y KHOA: Trích xuất văn bản chính xác.`;
    const prompt = "Hãy trích xuất văn bản từ hình ảnh này.";

    if (this.isCurrentKeyProxy(key)) {
      return await this.callOpenAINonStream(key, this.modelName, systemInstruction, prompt, imageBuffer, undefined);
    }

    try {
      const googleModel = this.mapModelForGoogle(this.modelName);
      const genModel = ai.getGenerativeModel({ 
        model: googleModel,
        systemInstruction: systemInstruction,
        generationConfig: { temperature: 0.1 }
      });
      const result = await genModel.generateContent([
        prompt, 
        { inlineData: { mimeType: "image/jpeg", data: imageBuffer.split(",")[1] || imageBuffer } }
      ]);
      const response = await result.response;
      return response.text()?.trim() || "";
    } catch (error: any) {
      throw error;
    }
  }

  async *summarizeContent(content: string, type: 'page' | 'document' | 'chapter', signal?: AbortSignal): AsyncGenerator<string> {
    const systemInstruction = `BÁC SĨ CHUYÊN KHOA: Tóm tắt nội dung y khoa Markdown.`;
    const prompt = `Tóm tắt (${type}):\n\n${content}`;

    let ai, key: string;
    try { ({ ai, key } = await this.acquireKeyAndInstance()); } catch (e) { throw new Error("API Key error."); }

    if (this.isCurrentKeyProxy(key)) {
      for await (const chunkText of this.callOpenAIStream(key, this.modelName, systemInstruction, prompt, "", signal)) {
        if (signal?.aborted) break;
        yield chunkText;
      }
      return;
    }

    try {
      const googleModel = this.mapModelForGoogle(this.modelName);
      const genModel = ai.getGenerativeModel({ 
        model: googleModel,
        systemInstruction: systemInstruction,
        generationConfig: { temperature: 0.2 }
      });
      const response = await genModel.generateContentStream(prompt);
      for await (const chunk of response.stream) {
        if (signal?.aborted) throw new Error("Aborted");
        if (chunk.text()) yield chunk.text();
      }
    } catch (error: any) { throw error; }
  }
  /**
   * Dịch giữ định dạng: dịch danh sách khối chữ (đã trích từ PDF) sang tiếng Việt.
   * Trả về map id → bản dịch. Khối nào model bỏ sót sẽ không có trong map (giữ nguyên chữ gốc).
   */
  async translateLayoutBlocks(
    blocks: { id: string; text: string }[],
    signal?: AbortSignal
  ): Promise<Record<string, string>> {
    if (!blocks.length) return {};

    const systemInstruction = `Bạn là chuyên gia dịch thuật y khoa Anh → Việt, đang dịch từng KHỐI CHỮ của một trang PDF để đặt lại đúng vị trí trên trang gốc.
QUY TẮC:
1. Dịch mỗi khối sang tiếng Việt chuẩn y khoa, tự nhiên, chính xác. Các khối liền nhau thuộc cùng một bài, giữ thuật ngữ nhất quán.
2. Bản dịch phải vừa khung chữ gốc: ưu tiên câu gọn, không thêm giải thích, không thêm chú thích trong ngoặc nếu bản gốc không có.
3. Giữ nguyên: số liệu, đơn vị, ký hiệu (±, ≤, ≥, ×, µ, °), tên thuốc gốc, tên gen/protein, từ viết tắt (CT, MRI, HbA1c…), ký tự chỉ số trên (¹²³), tên người, tên tạp chí, URL, DOI, email.
4. Mục tài liệu tham khảo (danh sách trích dẫn: tác giả, tên bài, tạp chí, năm) GIỮ NGUYÊN không dịch.
5. "Figure n" → "Hình n", "Table n" → "Bảng n", "Abstract" → "Tóm tắt", "Introduction" → "Đặt vấn đề", "Methods" → "Phương pháp", "Results" → "Kết quả", "Discussion" → "Bàn luận", "Conclusion(s)" → "Kết luận", "References" → "Tài liệu tham khảo".
6. Khối là tiêu đề viết HOA thì bản dịch cũng viết HOA.
7. Không dùng Markdown, không dùng LaTeX, không xuống dòng trong một khối.
8. Trả về DUY NHẤT JSON hợp lệ dạng {"t":[{"id":"b1","v":"bản dịch"}]} với đủ mọi id đã nhận.`;

    const prompt = `Dịch các khối sau (giữ nguyên id):\n${JSON.stringify(blocks.map(b => ({ id: b.id, text: b.text })))}`;

    const parse = (raw: string): Record<string, string> => {
      let txt = (raw || '').replace(/```json|```/gi, '').trim();
      const start = txt.indexOf('{');
      const end = txt.lastIndexOf('}');
      if (start >= 0 && end > start) txt = txt.slice(start, end + 1);
      const data = JSON.parse(txt);
      const arr: any[] = Array.isArray(data) ? data : (data.t || data.translations || []);
      const out: Record<string, string> = {};
      for (const item of arr) {
        const id = String(item?.id ?? '');
        const v = item?.v ?? item?.text ?? item?.translation;
        if (id && typeof v === 'string' && v.trim()) out[id] = cleanLatex(v).replace(/\*\*/g, '').replace(/\s*\n\s*/g, ' ').trim();
      }
      if (Object.keys(out).length === 0) throw new Error('Phản hồi dịch không có khối nào hợp lệ.');
      return out;
    };

    const MAX_RETRIES = 5;
    let retryCount = 0;
    while (retryCount <= MAX_RETRIES) {
      if (signal?.aborted) throw new Error('Translation aborted');
      let ai: any, key: string;
      try {
        ({ ai, key } = await this.acquireKeyAndInstance());
      } catch {
        throw new Error('Không tìm thấy API Key khả dụng. Vui lòng kiểm tra lại Key trong Cài đặt.');
      }

      try {
        let raw = '';
        if (this.isCurrentKeyProxy(key)) {
          raw = await this.callOpenAINonStream(key, this.modelName, systemInstruction, prompt, '', signal);
        } else {
          const genModel = ai.getGenerativeModel({
            model: this.mapModelForGoogle(this.modelName),
            systemInstruction,
            generationConfig: { temperature: 0.1, responseMimeType: 'application/json' },
          });
          const result = await genModel.generateContent(prompt, signal ? ({ signal } as any) : undefined);
          raw = (await result.response).text() || '';
        }
        const parsed = parse(raw);
        GeminiService.lastSuccessfulKey = key;
        return parsed;
      } catch (error: any) {
        if (signal?.aborted) throw new Error('Translation aborted');
        const msg = String(error?.message || '').toLowerCase();
        // Lỗi phân quyền (Level) không nên thử lại
        if (msg.includes('level 2') || msg.includes('đăng nhập')) throw error;
        const isQuota = msg.includes('429') || msg.includes('quota') || msg.includes('resource_exhausted') || msg.includes('401');
        if (retryCount < MAX_RETRIES && this.rotateKey(key, isQuota)) {
          retryCount++;
          const delay = Math.min(8000, Math.pow(1.5, retryCount) * 800 + Math.random() * 500);
          await new Promise(resolve => setTimeout(resolve, delay));
          continue;
        }
        throw error;
      }
    }
    throw new Error('Quá số lần thử lại khi dịch khối chữ.');
  }
}


